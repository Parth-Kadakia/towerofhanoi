﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MatchSelection
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Venue = New System.Windows.Forms.ComboBox()
        Me.Team2 = New System.Windows.Forms.ComboBox()
        Me.Team1 = New System.Windows.Forms.ComboBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Franklin Gothic Heavy", 26.14286!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(219, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(598, 78)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Beach Cricket 2017"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Venue)
        Me.GroupBox1.Controls.Add(Me.Team2)
        Me.GroupBox1.Controls.Add(Me.Team1)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 127)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1000, 487)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Match Selection"
        '
        'Venue
        '
        Me.Venue.FormattingEnabled = True
        Me.Venue.Items.AddRange(New Object() {"Bondi Beach - Australia", "Cable Beach - Australia", "St. Martin's Island - Bangladesh", "Cox's Bazar Beach - Bangladesh", "Baia do Sancho - Brazil", "Littlehampton - England", "Covean - England", "Treyarnon Bay - England", "Ngapali Beach - Myanmar", "Camp's Bay Beach - South Africa", "Seven Mile Beach - Jamaica", "Radhanagar Beach - India", "Dandi Beach - India", "Juhu Beach - India", "Baga Beach - India", "Candolim Beach - India", "Gadani Beach - Pakistan", "Gwadar Beach - Pakistan"})
        Me.Venue.Location = New System.Drawing.Point(220, 303)
        Me.Venue.Name = "Venue"
        Me.Venue.Size = New System.Drawing.Size(728, 32)
        Me.Venue.TabIndex = 7
        '
        'Team2
        '
        Me.Team2.FormattingEnabled = True
        Me.Team2.Location = New System.Drawing.Point(220, 182)
        Me.Team2.Name = "Team2"
        Me.Team2.Size = New System.Drawing.Size(728, 32)
        Me.Team2.TabIndex = 6
        '
        'Team1
        '
        Me.Team1.FormattingEnabled = True
        Me.Team1.Location = New System.Drawing.Point(220, 68)
        Me.Team1.Name = "Team1"
        Me.Team1.Size = New System.Drawing.Size(728, 32)
        Me.Team1.TabIndex = 5
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Franklin Gothic Heavy", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(632, 385)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(316, 86)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Main Menu"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Franklin Gothic Heavy", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(51, 385)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(316, 86)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Play Match"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Franklin Gothic Heavy", 14.14286!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(45, 299)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(119, 39)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Venue"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Franklin Gothic Heavy", 14.14286!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(45, 176)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(131, 39)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Team 2"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Franklin Gothic Heavy", 14.14286!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(45, 63)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(131, 39)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Team 1"
        '
        'MatchSelection
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 24.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1024, 626)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "MatchSelection"
        Me.Text = "MatchSelection"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Venue As ComboBox
    Friend WithEvents Team2 As ComboBox
    Friend WithEvents Team1 As ComboBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
End Class
