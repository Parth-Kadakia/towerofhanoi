﻿Public Class Toss
    Dim r As Random = New Random
    Shared toss_number As Integer

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim value = r.Next(1, 4)
        MsgBox(value)
        If (value = 1) Then
            'Team 1 Wins Bats
            TossResultText.Text = MatchSelection.Team1.Text & " has won the toss and elected to bat first"
            Button1.Enabled = False
            Button2.Enabled = True
            Label3.Text = 1
            MsgBox("1")
        ElseIf (value = 2) Then
            'Team 1 Wins Bowls
            TossResultText.Text = MatchSelection.Team1.Text & " has won the toss and elected to bowl first"
            Button1.Enabled = False
            Button2.Enabled = True
            Label3.Text = 2
            MsgBox("2")
        ElseIf (value = 3) Then
            'Team 2 Wins Bowls
            TossResultText.Text = MatchSelection.Team2.Text & " has won the toss and elected to bat first"
            Button1.Enabled = False
            Button2.Enabled = True
            Label3.Text = 2
            MsgBox("2")
        ElseIf (value = 4) Then
            'Team 2 Wins Bowls
            TossResultText.Text = MatchSelection.Team2.Text & " has won the toss and elected to bowl first"
            Button1.Enabled = False
            Button2.Enabled = True
            Label3.Text = 1
            MsgBox("1")
        End If
    End Sub

    Private Sub Toss_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.Text = MatchSelection.Team1.Text & " vs " & MatchSelection.Team2.Text
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Hide()
        Match.Show()

    End Sub
End Class