﻿Imports System
Imports System.IO
Imports System.Text
Public Class Match
    Dim team1 As String
    Dim team2 As String
    Dim venue As String
    Dim FILE_NAME1 As String
    Dim FILE_NAME2 As String
    Dim r As Random = New Random()
    Dim outcome As Integer

    Dim t1bat1runs As Integer
    Dim t1bat2runs As Integer
    Dim t1bat3runs As Integer
    Dim t1bat4runs As Integer
    Dim t1bat5runs As Integer

    Dim t1bat1bf As Integer
    Dim t1bat2bf As Integer
    Dim t1bat3bf As Integer
    Dim t1bat4bf As Integer
    Dim t1bat5bf As Integer

    Dim t2bat1runs As Integer
    Dim t2bat2runs As Integer
    Dim t2bat3runs As Integer
    Dim t2bat4runs As Integer
    Dim t2bat5runs As Integer

    Dim t2bat1bf As Integer
    Dim t2bat2bf As Integer
    Dim t2bat3bf As Integer
    Dim t2bat4bf As Integer
    Dim t2bat5bf As Integer

    Dim inn1_wickets As Integer
    Dim inn2_wickets As Integer

    Dim t1s As Integer
    Dim t1b As Integer

    Dim t2s As Integer
    Dim t2b As Integer

    Dim t1bowr1 As Integer
    Dim t1bowr2 As Integer
    Dim t1bowr3 As Integer

    Dim t1bowb1 As Integer
    Dim t1bowb2 As Integer
    Dim t1bowb3 As Integer

    Dim t1bowwk1 As Integer
    Dim t1bowwk2 As Integer
    Dim t1bowwk3 As Integer

    Dim t2bowr1 As Integer
    Dim t2bowr2 As Integer
    Dim t2bowr3 As Integer

    Dim t2bowb1 As Integer
    Dim t2bowb2 As Integer
    Dim t2bowb3 As Integer

    Dim t2bowwk1 As Integer
    Dim t2bowwk2 As Integer
    Dim t2bowwk3 As Integer





    Private Sub Match_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        team1 = MatchSelection.Team1.Text
        team2 = MatchSelection.Team2.Text
        venue = MatchSelection.Venue.Text
        GroupBox1.Text = team1 & " Innings"
        GroupBox2.Text = team2 & " Innings"
        MatchText.Text = "Friendly " & team1 & " vs " & team2
        VenueText.Text = "Venue - " & venue
        FILE_NAME1 = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\teams\" & team1 & ".txt"
        FILE_NAME2 = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\teams\" & team2 & ".txt"

        If Not File.Exists(FILE_NAME1) Then
            MsgBox("File does not exist")
        ElseIf Not File.Exists(FILE_NAME2) Then
            MsgBox("File does not exist")
        Else
            Using reader1 As StreamReader = New StreamReader(FILE_NAME1)
                ' Read one line from file
                T1B1.Text = reader1.ReadLine
                T1B2.Text = reader1.ReadLine
                T1B3.Text = reader1.ReadLine
                T1B4.Text = reader1.ReadLine
                T1B5.Text = reader1.ReadLine
                T1BW1.Text = T1B5.Text
                T1BW2.Text = T1B4.Text
                T1BW3.Text = T1B3.Text
            End Using

            Using reader2 As StreamReader = New StreamReader(FILE_NAME2)
                ' Read one line from file
                T2B1.Text = reader2.ReadLine
                T2B2.Text = reader2.ReadLine
                T2B3.Text = reader2.ReadLine
                T2B4.Text = reader2.ReadLine
                T2B5.Text = reader2.ReadLine
                T2BW1.Text = T2B5.Text
                T2BW2.Text = T2B4.Text
                T2BW3.Text = T2B3.Text
            End Using
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Main.Show()
        Me.Close()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If (Integer.Parse(Toss.Label3.Text) = 1) Then
            For value As Integer = 1 To 24
                FirstOverF1(value)
                SecondOverF1(value)
                ThirdOverF1(value)
            Next
        ElseIf (Integer.Parse(Toss.Label3.Text) = 2) Then
            For value As Integer = 1 To 24
                FirstOverF2(value)
                SecondOverF2(value)
                ThirdOverF2(value)
            Next
        End If

        DisplayScorecard()
        Button3.Enabled = False
    End Sub

    Private Sub FirstOverF2(value As Integer)
        If (value < 9 And inn2_wickets = 0) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t2bat1runs = t2bat1runs + 0
                t2bat1bf = t2bat1bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 0
            ElseIf (outcome = 1) Then
                t2bat1runs = t2bat1runs + 1
                t2bat1bf = t2bat1bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 1
            ElseIf (outcome = 2) Then
                t2bat1runs = t2bat1runs + 2
                t2bat1bf = t2bat1bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 2
            ElseIf (outcome = 3) Then
                t2bat1runs = t2bat1runs + 3
                t2bat1bf = t2bat1bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 3
            ElseIf (outcome = 4) Then
                t2bat1runs = t2bat1runs + 4
                t2bat1bf = t2bat1bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 4
            ElseIf (outcome = 5) Then
                t2bat1runs = t2bat1runs + 0
                t2bat1bf = t2bat1bf + 1
                inn2_wickets = inn2_wickets + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 0
                t1bowwk1 = t1bowwk1 + 1
            ElseIf (outcome = 6) Then
                t2bat1runs = t2bat1runs + 6
                t2bat1bf = t2bat1bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 6
            End If
        ElseIf (value < 9 And inn2_wickets = 1) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t2bat2runs = t2bat2runs + 0
                t2bat2bf = t2bat2bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 0
            ElseIf (outcome = 1) Then
                t2bat2runs = t2bat2runs + 1
                t2bat2bf = t2bat2bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 1
            ElseIf (outcome = 2) Then
                t2bat2runs = t2bat2runs + 2
                t2bat2bf = t2bat2bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 2
            ElseIf (outcome = 3) Then
                t2bat2runs = t2bat2runs + 3
                t2bat2bf = t2bat2bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 3
            ElseIf (outcome = 4) Then
                t2bat2runs = t2bat2runs + 4
                t2bat2bf = t2bat2bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 4
            ElseIf (outcome = 5) Then
                t2bat2runs = t2bat2runs + 0
                t2bat2bf = t2bat2bf + 1
                inn2_wickets = inn2_wickets + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 0
                t1bowwk1 = t1bowwk1 + 1
            ElseIf (outcome = 6) Then
                t2bat2runs = t2bat2runs + 6
                t2bat2bf = t2bat2bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 6
            End If
        ElseIf (value < 9 And inn2_wickets = 2) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t2bat3runs = t2bat3runs + 0
                t2bat3bf = t2bat3bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 0
            ElseIf (outcome = 1) Then
                t2bat3runs = t2bat3runs + 1
                t2bat3bf = t2bat3bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 1
            ElseIf (outcome = 2) Then
                t2bat3runs = t2bat3runs + 2
                t2bat3bf = t2bat3bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 2
            ElseIf (outcome = 3) Then
                t2bat3runs = t2bat3runs + 3
                t2bat3bf = t2bat3bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 3
            ElseIf (outcome = 4) Then
                t2bat3runs = t2bat3runs + 4
                t2bat3bf = t2bat3bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 4
            ElseIf (outcome = 5) Then
                t2bat3runs = t2bat3runs + 0
                t2bat3bf = t2bat3bf + 1
                inn2_wickets = inn2_wickets + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 0
                t1bowwk1 = t1bowwk1 + 1
            ElseIf (outcome = 6) Then
                t2bat3runs = t2bat3runs + 6
                t2bat3bf = t2bat3bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 6
            End If
        ElseIf (value < 9 And inn2_wickets = 3) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t2bat4runs = t2bat4runs + 0
                t2bat4bf = t2bat4bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 0
            ElseIf (outcome = 1) Then
                t2bat4runs = t2bat4runs + 1
                t2bat4bf = t2bat4bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 1
            ElseIf (outcome = 2) Then
                t2bat4runs = t2bat4runs + 2
                t2bat4bf = t2bat4bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 2
            ElseIf (outcome = 3) Then
                t2bat4runs = t2bat4runs + 3
                t2bat4bf = t2bat4bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 3
            ElseIf (outcome = 4) Then
                t2bat4runs = t2bat4runs + 4
                t2bat4bf = t2bat4bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 4
            ElseIf (outcome = 5) Then
                t2bat4runs = t2bat4runs + 0
                t2bat4bf = t2bat4bf + 1
                inn2_wickets = inn2_wickets + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 0
                t1bowwk1 = t1bowwk1 + 1
            ElseIf (outcome = 6) Then
                t2bat4runs = t2bat4runs + 6
                t2bat4bf = t2bat4bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 6
            End If
        ElseIf (value < 9 And inn2_wickets = 4) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t2bat5runs = t2bat5runs + 0
                t2bat5bf = t2bat5bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 0
            ElseIf (outcome = 1) Then
                t2bat5runs = t2bat5runs + 1
                t2bat5bf = t2bat5bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 1
            ElseIf (outcome = 2) Then
                t2bat5runs = t2bat5runs + 2
                t2bat5bf = t2bat5bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 2
            ElseIf (outcome = 3) Then
                t2bat5runs = t2bat5runs + 3
                t2bat5bf = t2bat5bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 3
            ElseIf (outcome = 4) Then
                t2bat5runs = t2bat5runs + 4
                t2bat5bf = t2bat5bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 4
            ElseIf (outcome = 5) Then
                t2bat5runs = t2bat5runs + 0
                t2bat5bf = t2bat5bf + 1
                inn2_wickets = inn2_wickets + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 0
                t1bowwk1 = t1bowwk1 + 1
            ElseIf (outcome = 6) Then
                t2bat5runs = t2bat5runs + 6
                t2bat5bf = t2bat5bf + 1
                t1bowb1 = t1bowb1 + 1
                t1bowr1 = t1bowr1 + 6
            End If

        End If
    End Sub

    Private Sub SecondOverF2(value As Integer)
        If (value > 8 And value < 17 And inn2_wickets = 0) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t2bat1runs = t2bat1runs + 0
                t2bat1bf = t2bat1bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 0
            ElseIf (outcome = 1) Then
                t2bat1runs = t2bat1runs + 1
                t2bat1bf = t2bat1bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 1
            ElseIf (outcome = 2) Then
                t2bat1runs = t2bat1runs + 2
                t2bat1bf = t2bat1bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 2
            ElseIf (outcome = 3) Then
                t2bat1runs = t2bat1runs + 3
                t2bat1bf = t2bat1bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 3
            ElseIf (outcome = 4) Then
                t2bat1runs = t2bat1runs + 4
                t2bat1bf = t2bat1bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 4
            ElseIf (outcome = 5) Then
                t2bat1runs = t2bat1runs + 0
                t2bat1bf = t2bat1bf + 1
                inn2_wickets = inn2_wickets + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 0
                t1bowwk2 = t1bowwk2 + 1
            ElseIf (outcome = 6) Then
                t2bat1runs = t2bat1runs + 6
                t2bat1bf = t2bat1bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 6
            End If
        ElseIf (value > 8 And value < 17 And inn2_wickets = 1) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t2bat2runs = t2bat2runs + 0
                t2bat2bf = t2bat2bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 0
            ElseIf (outcome = 1) Then
                t2bat2runs = t2bat2runs + 1
                t2bat2bf = t2bat2bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 1
            ElseIf (outcome = 2) Then
                t2bat2runs = t2bat2runs + 2
                t2bat2bf = t2bat2bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 2
            ElseIf (outcome = 3) Then
                t2bat2runs = t2bat2runs + 3
                t2bat2bf = t2bat2bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 3
            ElseIf (outcome = 4) Then
                t2bat2runs = t2bat2runs + 4
                t2bat2bf = t2bat2bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 4
            ElseIf (outcome = 5) Then
                t2bat2runs = t2bat2runs + 0
                t2bat2bf = t2bat2bf + 1
                inn2_wickets = inn2_wickets + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 0
                t1bowwk2 = t1bowwk2 + 1
            ElseIf (outcome = 6) Then
                t2bat2runs = t2bat2runs + 6
                t2bat2bf = t2bat2bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 6
            End If
        ElseIf (value > 8 And value < 17 And inn2_wickets = 2) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t2bat3runs = t2bat3runs + 0
                t2bat3bf = t2bat3bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 0
            ElseIf (outcome = 1) Then
                t2bat3runs = t2bat3runs + 1
                t2bat3bf = t2bat3bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 1
            ElseIf (outcome = 2) Then
                t2bat3runs = t2bat3runs + 2
                t2bat3bf = t2bat3bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 2
            ElseIf (outcome = 3) Then
                t2bat3runs = t2bat3runs + 3
                t2bat3bf = t2bat3bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 3
            ElseIf (outcome = 4) Then
                t2bat3runs = t2bat3runs + 4
                t2bat3bf = t2bat3bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 4
            ElseIf (outcome = 5) Then
                t2bat3runs = t2bat3runs + 0
                t2bat3bf = t2bat3bf + 1
                inn2_wickets = inn2_wickets + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 0
                t1bowwk2 = t1bowwk2 + 1
            ElseIf (outcome = 6) Then
                t2bat3runs = t2bat3runs + 6
                t2bat3bf = t2bat3bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 6
            End If
        ElseIf (value > 8 And value < 17 And inn2_wickets = 3) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t2bat4runs = t2bat4runs + 0
                t2bat4bf = t2bat4bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 0
            ElseIf (outcome = 1) Then
                t2bat4runs = t2bat4runs + 1
                t2bat4bf = t2bat4bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 1
            ElseIf (outcome = 2) Then
                t2bat4runs = t2bat4runs + 2
                t2bat4bf = t2bat4bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 2
            ElseIf (outcome = 3) Then
                t2bat4runs = t2bat4runs + 3
                t2bat4bf = t2bat4bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 3
            ElseIf (outcome = 4) Then
                t2bat4runs = t2bat4runs + 4
                t2bat4bf = t2bat4bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 4
            ElseIf (outcome = 5) Then
                t2bat4runs = t2bat4runs + 0
                t2bat4bf = t2bat4bf + 1
                inn2_wickets = inn2_wickets + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 0
                t1bowwk2 = t1bowwk2 + 1
            ElseIf (outcome = 6) Then
                t2bat4runs = t2bat4runs + 6
                t2bat4bf = t2bat4bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 6
            End If
        ElseIf (value > 8 And value < 17 And inn2_wickets = 4) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t2bat5runs = t2bat5runs + 0
                t2bat5bf = t2bat5bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 0
            ElseIf (outcome = 1) Then
                t2bat5runs = t2bat5runs + 1
                t2bat5bf = t2bat5bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 1
            ElseIf (outcome = 2) Then
                t2bat5runs = t2bat5runs + 2
                t2bat5bf = t2bat5bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 2
            ElseIf (outcome = 3) Then
                t2bat5runs = t2bat5runs + 3
                t2bat5bf = t2bat5bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 3
            ElseIf (outcome = 4) Then
                t2bat5runs = t2bat5runs + 4
                t2bat5bf = t2bat5bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 4
            ElseIf (outcome = 5) Then
                t2bat5runs = t2bat5runs + 0
                t2bat5bf = t2bat5bf + 1
                inn2_wickets = inn2_wickets + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 0
                t1bowwk2 = t1bowwk2 + 1
            ElseIf (outcome = 6) Then
                t2bat5runs = t2bat5runs + 6
                t2bat5bf = t2bat5bf + 1
                t1bowb2 = t1bowb2 + 1
                t1bowr2 = t1bowr2 + 6
            End If

        End If
    End Sub

    Private Sub ThirdOverF2(value As Integer)
        If (value > 16 And value < 25 And inn2_wickets = 0) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t2bat1runs = t2bat1runs + 0
                t2bat1bf = t2bat1bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 0
            ElseIf (outcome = 1) Then
                t2bat1runs = t2bat1runs + 1
                t2bat1bf = t2bat1bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 1
            ElseIf (outcome = 2) Then
                t2bat1runs = t2bat1runs + 2
                t2bat1bf = t2bat1bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 2
            ElseIf (outcome = 3) Then
                t2bat1runs = t2bat1runs + 3
                t2bat1bf = t2bat1bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 3
            ElseIf (outcome = 4) Then
                t2bat1runs = t2bat1runs + 4
                t2bat1bf = t2bat1bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 4
            ElseIf (outcome = 5) Then
                t2bat1runs = t2bat1runs + 0
                t2bat1bf = t2bat1bf + 1
                inn2_wickets = inn2_wickets + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 0
                t1bowwk3 = t1bowwk3 + 1
            ElseIf (outcome = 6) Then
                t2bat1runs = t2bat1runs + 6
                t2bat1bf = t2bat1bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 6
            End If
        ElseIf (value > 16 And value < 25 And inn2_wickets = 1) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t2bat2runs = t2bat2runs + 0
                t2bat2bf = t2bat2bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 0
            ElseIf (outcome = 1) Then
                t2bat2runs = t2bat2runs + 1
                t2bat2bf = t2bat2bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 1
            ElseIf (outcome = 2) Then
                t2bat2runs = t2bat2runs + 2
                t2bat2bf = t2bat2bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 2
            ElseIf (outcome = 3) Then
                t2bat2runs = t2bat2runs + 3
                t2bat2bf = t2bat2bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 3
            ElseIf (outcome = 4) Then
                t2bat2runs = t2bat2runs + 4
                t2bat2bf = t2bat2bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 4
            ElseIf (outcome = 5) Then
                t2bat2runs = t2bat2runs + 0
                t2bat2bf = t2bat2bf + 1
                inn2_wickets = inn2_wickets + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 0
                t1bowwk3 = t1bowwk3 + 1
            ElseIf (outcome = 6) Then
                t2bat2runs = t2bat2runs + 6
                t2bat2bf = t2bat2bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 6
            End If
        ElseIf (value > 16 And value < 25 And inn2_wickets = 2) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t2bat3runs = t2bat3runs + 0
                t2bat3bf = t2bat3bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 0
            ElseIf (outcome = 1) Then
                t2bat3runs = t2bat3runs + 1
                t2bat3bf = t2bat3bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 1
            ElseIf (outcome = 2) Then
                t2bat3runs = t2bat3runs + 2
                t2bat3bf = t2bat3bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 2
            ElseIf (outcome = 3) Then
                t2bat3runs = t2bat3runs + 3
                t2bat3bf = t2bat3bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 3
            ElseIf (outcome = 4) Then
                t2bat3runs = t2bat3runs + 4
                t2bat3bf = t2bat3bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 4
            ElseIf (outcome = 5) Then
                t2bat3runs = t2bat3runs + 0
                t2bat3bf = t2bat3bf + 1
                inn2_wickets = inn2_wickets + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 0
                t1bowwk3 = t1bowwk3 + 1
            ElseIf (outcome = 6) Then
                t2bat3runs = t2bat3runs + 6
                t2bat3bf = t2bat3bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 6
            End If
        ElseIf (value > 16 And value < 25 And inn2_wickets = 3) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t2bat4runs = t2bat4runs + 0
                t2bat4bf = t2bat4bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 0
            ElseIf (outcome = 1) Then
                t2bat4runs = t2bat4runs + 1
                t2bat4bf = t2bat4bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 1
            ElseIf (outcome = 2) Then
                t2bat4runs = t2bat4runs + 2
                t2bat4bf = t2bat4bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 2
            ElseIf (outcome = 3) Then
                t2bat4runs = t2bat4runs + 3
                t2bat4bf = t2bat4bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 3
            ElseIf (outcome = 4) Then
                t2bat4runs = t2bat4runs + 4
                t2bat4bf = t2bat4bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 4
            ElseIf (outcome = 5) Then
                t2bat4runs = t2bat4runs + 0
                t2bat4bf = t2bat4bf + 1
                inn2_wickets = inn2_wickets + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 0
                t1bowwk3 = t1bowwk3 + 1
            ElseIf (outcome = 6) Then
                t2bat4runs = t2bat4runs + 6
                t2bat4bf = t2bat4bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 6
            End If
        ElseIf (value > 16 And value < 25 And inn2_wickets = 4) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t2bat5runs = t2bat5runs + 0
                t2bat5bf = t2bat5bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 0
            ElseIf (outcome = 1) Then
                t2bat5runs = t2bat5runs + 1
                t2bat5bf = t2bat5bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 1
            ElseIf (outcome = 2) Then
                t2bat5runs = t2bat5runs + 2
                t2bat5bf = t2bat5bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 2
            ElseIf (outcome = 3) Then
                t2bat5runs = t2bat5runs + 3
                t2bat5bf = t2bat5bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 3
            ElseIf (outcome = 4) Then
                t2bat5runs = t2bat5runs + 4
                t2bat5bf = t2bat5bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 4
            ElseIf (outcome = 5) Then
                t2bat5runs = t2bat5runs + 0
                t2bat5bf = t2bat5bf + 1
                inn2_wickets = inn2_wickets + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 0
                t1bowwk3 = t1bowwk3 + 1
            ElseIf (outcome = 6) Then
                t2bat5runs = t2bat5runs + 6
                t2bat5bf = t2bat5bf + 1
                t1bowb3 = t1bowb3 + 1
                t1bowr3 = t1bowr3 + 6
            End If

        End If
    End Sub


    Private Sub FirstOverF1(value As Integer)
        If (value < 9 And inn1_wickets = 0) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t1bat1runs = t1bat1runs + 0
                t1bat1bf = t1bat1bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 0
            ElseIf (outcome = 1) Then
                t1bat1runs = t1bat1runs + 1
                t1bat1bf = t1bat1bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 1
            ElseIf (outcome = 2) Then
                t1bat1runs = t1bat1runs + 2
                t1bat1bf = t1bat1bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 2
            ElseIf (outcome = 3) Then
                t1bat1runs = t1bat1runs + 3
                t1bat1bf = t1bat1bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 3
            ElseIf (outcome = 4) Then
                t1bat1runs = t1bat1runs + 4
                t1bat1bf = t1bat1bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 4
            ElseIf (outcome = 5) Then
                t1bat1runs = t1bat1runs + 0
                t1bat1bf = t1bat1bf + 1
                inn1_wickets = inn1_wickets + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 0
                t2bowwk1 = t2bowwk1 + 1
            ElseIf (outcome = 6) Then
                t1bat1runs = t1bat1runs + 6
                t1bat1bf = t1bat1bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 6
            End If
        ElseIf (value < 9 And inn1_wickets = 1) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t1bat2runs = t1bat2runs + 0
                t1bat2bf = t1bat2bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 0
            ElseIf (outcome = 1) Then
                t1bat2runs = t1bat2runs + 1
                t1bat2bf = t1bat2bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 1
            ElseIf (outcome = 2) Then
                t1bat2runs = t1bat2runs + 2
                t1bat2bf = t1bat2bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 2
            ElseIf (outcome = 3) Then
                t1bat2runs = t1bat2runs + 3
                t1bat2bf = t1bat2bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 3
            ElseIf (outcome = 4) Then
                t1bat2runs = t1bat2runs + 4
                t1bat2bf = t1bat2bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 4
            ElseIf (outcome = 5) Then
                t1bat2runs = t1bat2runs + 0
                t1bat2bf = t1bat2bf + 1
                inn1_wickets = inn1_wickets + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 0
                t2bowwk1 = t2bowwk1 + 1
            ElseIf (outcome = 6) Then
                t1bat2runs = t1bat2runs + 6
                t1bat2bf = t1bat2bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 6
            End If
        ElseIf (value < 9 And inn1_wickets = 2) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t1bat3runs = t1bat3runs + 0
                t1bat3bf = t1bat3bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 0
            ElseIf (outcome = 1) Then
                t1bat3runs = t1bat3runs + 1
                t1bat3bf = t1bat3bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 1
            ElseIf (outcome = 2) Then
                t1bat3runs = t1bat3runs + 2
                t1bat3bf = t1bat3bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 2
            ElseIf (outcome = 3) Then
                t1bat3runs = t1bat3runs + 3
                t1bat3bf = t1bat3bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 3
            ElseIf (outcome = 4) Then
                t1bat3runs = t1bat3runs + 4
                t1bat3bf = t1bat3bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 4
            ElseIf (outcome = 5) Then
                t1bat3runs = t1bat3runs + 0
                t1bat3bf = t1bat3bf + 1
                inn1_wickets = inn1_wickets + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 0
                t2bowwk1 = t2bowwk1 + 1
            ElseIf (outcome = 6) Then
                t1bat3runs = t1bat3runs + 6
                t1bat3bf = t1bat3bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 6
            End If
        ElseIf (value < 9 And inn1_wickets = 3) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t1bat4runs = t1bat4runs + 0
                t1bat4bf = t1bat4bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 0
            ElseIf (outcome = 1) Then
                t1bat4runs = t1bat4runs + 1
                t1bat4bf = t1bat4bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 1
            ElseIf (outcome = 2) Then
                t1bat4runs = t1bat4runs + 2
                t1bat4bf = t1bat4bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 2
            ElseIf (outcome = 3) Then
                t1bat4runs = t1bat4runs + 3
                t1bat4bf = t1bat4bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 3
            ElseIf (outcome = 4) Then
                t1bat4runs = t1bat4runs + 4
                t1bat4bf = t1bat4bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 4
            ElseIf (outcome = 5) Then
                t1bat4runs = t1bat4runs + 0
                t1bat4bf = t1bat4bf + 1
                inn1_wickets = inn1_wickets + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 0
                t2bowwk1 = t2bowwk1 + 1
            ElseIf (outcome = 6) Then
                t1bat4runs = t1bat4runs + 6
                t1bat4bf = t1bat4bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 6
            End If
        ElseIf (value < 9 And inn1_wickets = 4) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t1bat5runs = t1bat5runs + 0
                t1bat5bf = t1bat5bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 0
            ElseIf (outcome = 1) Then
                t1bat5runs = t1bat5runs + 1
                t1bat5bf = t1bat5bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 1
            ElseIf (outcome = 2) Then
                t1bat5runs = t1bat5runs + 2
                t1bat5bf = t1bat5bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 2
            ElseIf (outcome = 3) Then
                t1bat5runs = t1bat5runs + 3
                t1bat5bf = t1bat5bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 3
            ElseIf (outcome = 4) Then
                t1bat5runs = t1bat5runs + 4
                t1bat5bf = t1bat5bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 4
            ElseIf (outcome = 5) Then
                t1bat5runs = t1bat5runs + 0
                t1bat5bf = t1bat5bf + 1
                inn1_wickets = inn1_wickets + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 0
                t2bowwk1 = t2bowwk1 + 1
            ElseIf (outcome = 6) Then
                t1bat5runs = t1bat5runs + 6
                t1bat5bf = t1bat5bf + 1
                t2bowb1 = t2bowb1 + 1
                t2bowr1 = t2bowr1 + 6
            End If

        End If
    End Sub

    Private Sub SecondOverF1(value As Integer)
        If (value > 8 And value < 17 And inn1_wickets = 0) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t1bat1runs = t1bat1runs + 0
                t1bat1bf = t1bat1bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 0
            ElseIf (outcome = 1) Then
                t1bat1runs = t1bat1runs + 1
                t1bat1bf = t1bat1bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 1
            ElseIf (outcome = 2) Then
                t1bat1runs = t1bat1runs + 2
                t1bat1bf = t1bat1bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 2
            ElseIf (outcome = 3) Then
                t1bat1runs = t1bat1runs + 3
                t1bat1bf = t1bat1bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 3
            ElseIf (outcome = 4) Then
                t1bat1runs = t1bat1runs + 4
                t1bat1bf = t1bat1bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 4
            ElseIf (outcome = 5) Then
                t1bat1runs = t1bat1runs + 0
                t1bat1bf = t1bat1bf + 1
                inn1_wickets = inn1_wickets + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 0
                t2bowwk2 = t2bowwk2 + 1
            ElseIf (outcome = 6) Then
                t1bat1runs = t1bat1runs + 6
                t1bat1bf = t1bat1bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 6
            End If
        ElseIf (value > 8 And value < 17 And inn1_wickets = 1) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t1bat2runs = t1bat2runs + 0
                t1bat2bf = t1bat2bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 0
            ElseIf (outcome = 1) Then
                t1bat2runs = t1bat2runs + 1
                t1bat2bf = t1bat2bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 1
            ElseIf (outcome = 2) Then
                t1bat2runs = t1bat2runs + 2
                t1bat2bf = t1bat2bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 2
            ElseIf (outcome = 3) Then
                t1bat2runs = t1bat2runs + 3
                t1bat2bf = t1bat2bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 3
            ElseIf (outcome = 4) Then
                t1bat2runs = t1bat2runs + 4
                t1bat2bf = t1bat2bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 4
            ElseIf (outcome = 5) Then
                t1bat2runs = t1bat2runs + 0
                t1bat2bf = t1bat2bf + 1
                inn1_wickets = inn1_wickets + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 0
                t2bowwk2 = t2bowwk2 + 1
            ElseIf (outcome = 6) Then
                t1bat2runs = t1bat2runs + 6
                t1bat2bf = t1bat2bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 6
            End If
        ElseIf (value > 8 And value < 17 And inn1_wickets = 2) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t1bat3runs = t1bat3runs + 0
                t1bat3bf = t1bat3bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 0
            ElseIf (outcome = 1) Then
                t1bat3runs = t1bat3runs + 1
                t1bat3bf = t1bat3bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 1
            ElseIf (outcome = 2) Then
                t1bat3runs = t1bat3runs + 2
                t1bat3bf = t1bat3bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 2
            ElseIf (outcome = 3) Then
                t1bat3runs = t1bat3runs + 3
                t1bat3bf = t1bat3bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 3
            ElseIf (outcome = 4) Then
                t1bat3runs = t1bat3runs + 4
                t1bat3bf = t1bat3bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 4
            ElseIf (outcome = 5) Then
                t1bat3runs = t1bat3runs + 0
                t1bat3bf = t1bat3bf + 1
                inn1_wickets = inn1_wickets + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 0
                t2bowwk2 = t2bowwk2 + 1
            ElseIf (outcome = 6) Then
                t1bat3runs = t1bat3runs + 6
                t1bat3bf = t1bat3bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 6
            End If
        ElseIf (value > 8 And value < 17 And inn1_wickets = 3) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t1bat4runs = t1bat4runs + 0
                t1bat4bf = t1bat4bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 0
            ElseIf (outcome = 1) Then
                t1bat4runs = t1bat4runs + 1
                t1bat4bf = t1bat4bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 1
            ElseIf (outcome = 2) Then
                t1bat4runs = t1bat4runs + 2
                t1bat4bf = t1bat4bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 2
            ElseIf (outcome = 3) Then
                t1bat4runs = t1bat4runs + 3
                t1bat4bf = t1bat4bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 3
            ElseIf (outcome = 4) Then
                t1bat4runs = t1bat4runs + 4
                t1bat4bf = t1bat4bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 4
            ElseIf (outcome = 5) Then
                t1bat4runs = t1bat4runs + 0
                t1bat4bf = t1bat4bf + 1
                inn1_wickets = inn1_wickets + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 0
                t2bowwk2 = t2bowwk2 + 1
            ElseIf (outcome = 6) Then
                t1bat4runs = t1bat4runs + 6
                t1bat4bf = t1bat4bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 6
            End If
        ElseIf (value > 8 And value < 17 And inn1_wickets = 4) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t1bat5runs = t1bat5runs + 0
                t1bat5bf = t1bat5bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 0
            ElseIf (outcome = 1) Then
                t1bat5runs = t1bat5runs + 1
                t1bat5bf = t1bat5bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 1
            ElseIf (outcome = 2) Then
                t1bat5runs = t1bat5runs + 2
                t1bat5bf = t1bat5bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 2
            ElseIf (outcome = 3) Then
                t1bat5runs = t1bat5runs + 3
                t1bat5bf = t1bat5bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 3
            ElseIf (outcome = 4) Then
                t1bat5runs = t1bat5runs + 4
                t1bat5bf = t1bat5bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 4
            ElseIf (outcome = 5) Then
                t1bat5runs = t1bat5runs + 0
                t1bat5bf = t1bat5bf + 1
                inn1_wickets = inn1_wickets + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 0
                t2bowwk2 = t2bowwk2 + 1
            ElseIf (outcome = 6) Then
                t1bat5runs = t1bat5runs + 6
                t1bat5bf = t1bat5bf + 1
                t2bowb2 = t2bowb2 + 1
                t2bowr2 = t2bowr2 + 6
            End If

        End If
    End Sub

    Private Sub ThirdOverF1(value As Integer)
        If (value > 16 And value < 25 And inn1_wickets = 0) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t1bat1runs = t1bat1runs + 0
                t1bat1bf = t1bat1bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 0
            ElseIf (outcome = 1) Then
                t1bat1runs = t1bat1runs + 1
                t1bat1bf = t1bat1bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 1
            ElseIf (outcome = 2) Then
                t1bat1runs = t1bat1runs + 2
                t1bat1bf = t1bat1bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 2
            ElseIf (outcome = 3) Then
                t1bat1runs = t1bat1runs + 3
                t1bat1bf = t1bat1bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 3
            ElseIf (outcome = 4) Then
                t1bat1runs = t1bat1runs + 4
                t1bat1bf = t1bat1bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 4
            ElseIf (outcome = 5) Then
                t1bat1runs = t1bat1runs + 0
                t1bat1bf = t1bat1bf + 1
                inn1_wickets = inn1_wickets + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 0
                t2bowwk3 = t2bowwk3 + 1
            ElseIf (outcome = 6) Then
                t1bat1runs = t1bat1runs + 6
                t1bat1bf = t1bat1bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 6
            End If
        ElseIf (value > 16 And value < 25 And inn1_wickets = 1) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t1bat2runs = t1bat2runs + 0
                t1bat2bf = t1bat2bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 0
            ElseIf (outcome = 1) Then
                t1bat2runs = t1bat2runs + 1
                t1bat2bf = t1bat2bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 1
            ElseIf (outcome = 2) Then
                t1bat2runs = t1bat2runs + 2
                t1bat2bf = t1bat2bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 2
            ElseIf (outcome = 3) Then
                t1bat2runs = t1bat2runs + 3
                t1bat2bf = t1bat2bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 3
            ElseIf (outcome = 4) Then
                t1bat2runs = t1bat2runs + 4
                t1bat2bf = t1bat2bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 4
            ElseIf (outcome = 5) Then
                t1bat2runs = t1bat2runs + 0
                t1bat2bf = t1bat2bf + 1
                inn1_wickets = inn1_wickets + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 0
                t2bowwk3 = t2bowwk3 + 1
            ElseIf (outcome = 6) Then
                t1bat2runs = t1bat2runs + 6
                t1bat2bf = t1bat2bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 6
            End If
        ElseIf (value > 16 And value < 25 And inn1_wickets = 2) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t1bat3runs = t1bat3runs + 0
                t1bat3bf = t1bat3bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 0
            ElseIf (outcome = 1) Then
                t1bat3runs = t1bat3runs + 1
                t1bat3bf = t1bat3bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 1
            ElseIf (outcome = 2) Then
                t1bat3runs = t1bat3runs + 2
                t1bat3bf = t1bat3bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 2
            ElseIf (outcome = 3) Then
                t1bat3runs = t1bat3runs + 3
                t1bat3bf = t1bat3bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 3
            ElseIf (outcome = 4) Then
                t1bat3runs = t1bat3runs + 4
                t1bat3bf = t1bat3bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 4
            ElseIf (outcome = 5) Then
                t1bat3runs = t1bat3runs + 0
                t1bat3bf = t1bat3bf + 1
                inn1_wickets = inn1_wickets + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 0
                t2bowwk3 = t2bowwk3 + 1
            ElseIf (outcome = 6) Then
                t1bat3runs = t1bat3runs + 6
                t1bat3bf = t1bat3bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 6
            End If
        ElseIf (value > 16 And value < 25 And inn1_wickets = 3) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t1bat4runs = t1bat4runs + 0
                t1bat4bf = t1bat4bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 0
            ElseIf (outcome = 1) Then
                t1bat4runs = t1bat4runs + 1
                t1bat4bf = t1bat4bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 1
            ElseIf (outcome = 2) Then
                t1bat4runs = t1bat4runs + 2
                t1bat4bf = t1bat4bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 2
            ElseIf (outcome = 3) Then
                t1bat4runs = t1bat4runs + 3
                t1bat4bf = t1bat4bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 3
            ElseIf (outcome = 4) Then
                t1bat4runs = t1bat4runs + 4
                t1bat4bf = t1bat4bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 4
            ElseIf (outcome = 5) Then
                t1bat4runs = t1bat4runs + 0
                t1bat4bf = t1bat4bf + 1
                inn1_wickets = inn1_wickets + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 0
                t2bowwk3 = t2bowwk3 + 1
            ElseIf (outcome = 6) Then
                t1bat4runs = t1bat4runs + 6
                t1bat4bf = t1bat4bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 6
            End If
        ElseIf (value > 16 And value < 25 And inn1_wickets = 4) Then
            outcome = r.Next(0, 6)
            If (outcome = 0) Then
                t1bat5runs = t1bat5runs + 0
                t1bat5bf = t1bat5bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 0
            ElseIf (outcome = 1) Then
                t1bat5runs = t1bat5runs + 1
                t1bat5bf = t1bat5bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 1
            ElseIf (outcome = 2) Then
                t1bat5runs = t1bat5runs + 2
                t1bat5bf = t1bat5bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 2
            ElseIf (outcome = 3) Then
                t1bat5runs = t1bat5runs + 3
                t1bat5bf = t1bat5bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 3
            ElseIf (outcome = 4) Then
                t1bat5runs = t1bat5runs + 4
                t1bat5bf = t1bat5bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 4
            ElseIf (outcome = 5) Then
                t1bat5runs = t1bat5runs + 0
                t1bat5bf = t1bat5bf + 1
                inn1_wickets = inn1_wickets + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 0
                t2bowwk3 = t2bowwk3 + 1
            ElseIf (outcome = 6) Then
                t1bat5runs = t1bat5runs + 6
                t1bat5bf = t1bat5bf + 1
                t2bowb3 = t2bowb3 + 1
                t2bowr3 = t2bowr3 + 6
            End If

        End If
    End Sub

    Private Sub DisplayScorecard()
        'team 1 update
        t1b = t1bat1bf + t1bat2bf + t1bat3bf + t1bat4bf + t1bat5bf
        t1s = t1bat1runs + t1bat2runs + t1bat3runs + t1bat4runs + t1bat5runs

        T1B1R.Text = t1bat1runs
        T1B1BF.Text = t1bat1bf
        T1B2R.Text = t1bat2runs
        T1B2BF.Text = t1bat2bf
        T1B3R.Text = t1bat3runs
        T1B3BF.Text = t1bat3bf
        T1B4R.Text = t1bat4runs
        T1B4BF.Text = t1bat4bf
        T1B5R.Text = t1bat5runs
        T1B5BF.Text = t1bat5bf

        T1TS.Text = t1s
        T1TB.Text = t1b
        T1TW.Text = inn1_wickets

        T1BWLBO1.Text = t1bowb1
        T1BWLRU1.Text = t1bowr1
        T1BWLWK1.Text = t1bowwk1

        T1BWLBO2.Text = t1bowb2
        T1BWLRU2.Text = t1bowr2
        T1BWLWK2.Text = t1bowwk2

        T1BWLBO3.Text = t1bowb3
        T1BWLRU3.Text = t1bowr3
        T1BWLWK3.Text = t1bowwk3

        'team 2 update

        t2b = t2bat1bf + t2bat2bf + t2bat3bf + t2bat4bf + t2bat5bf
        t2s = t2bat1runs + t2bat2runs + t2bat3runs + t2bat4runs + t2bat5runs

        T2B1R.Text = t2bat1runs
        T2B1BF.Text = t2bat1bf
        T2B2R.Text = t2bat2runs
        T2B2BF.Text = t2bat2bf
        T2B3R.Text = t2bat3runs
        T2B3BF.Text = t2bat3bf
        T2B4R.Text = t2bat4runs
        T2B4BF.Text = t2bat4bf
        T2B5R.Text = t2bat5runs
        T2B5BF.Text = t2bat5bf

        T2TS.Text = t2s
        T2TB.Text = t2b
        T2TW.Text = inn2_wickets

        T2BWLBO1.Text = t2bowb1
        T2BWLRU1.Text = t2bowr1
        T2BWLWK1.Text = t2bowwk1

        T2BWLBO2.Text = t2bowb2
        T2BWLRU2.Text = t2bowr2
        T2BWLWK2.Text = t2bowwk2

        T2BWLBO3.Text = t2bowb3
        T2BWLRU3.Text = t2bowr3
        T2BWLWK3.Text = t2bowwk3


    End Sub

    Private Sub winningcondition()
        If (Integer.Parse(Toss.Label3.Text) = 1) Then
            If (Integer.Parse(T2TS.Text) > Integer.Parse(T1TS.Text)) Then
                ResultText.Visible = True
                ResultText.Text = team2 & " wins"

            ElseIf (Integer.Parse(T2TS.Text) < Integer.Parse(T1TS.Text) Or Integer.Parse(T2TB.Text) = 24 Or Integer.Parse(T2TW.Text) = 5) Then
                ResultText.Text = team1 & " wins"
                ResultText.Visible = True
            End If
        ElseIf (Integer.Parse(Toss.Label3.Text) = 2) Then
            If (Integer.Parse(T1TS.Text) > Integer.Parse(T2TS.Text)) Then
                ResultText.Text = team1 & " wins"
                ResultText.Visible = True
            ElseIf (Integer.Parse(T1TS.Text) < Integer.Parse(T2TS.Text) Or Integer.Parse(T1TB.Text) = 24 Or Integer.Parse(T1TW.Text) = 5) Then
                ResultText.Text = team2 & " wins"
                ResultText.Visible = True
            End If
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If (Integer.Parse(Toss.Label3.Text) = 1) Then
            For value As Integer = 1 To 24
                FirstOverF2(value)
                SecondOverF2(value)
                ThirdOverF2(value)
            Next
        ElseIf (Integer.Parse(Toss.Label3.Text) = 2) Then
            For value As Integer = 1 To 24
                FirstOverF1(value)
                SecondOverF1(value)
                ThirdOverF1(value)
            Next
        End If
        winningcondition()
        DisplayScorecard()
        Button4.Enabled = False
    End Sub
End Class