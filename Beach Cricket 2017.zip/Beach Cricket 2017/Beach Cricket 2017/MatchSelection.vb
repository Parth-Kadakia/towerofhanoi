﻿Imports System
Imports System.IO
Imports System.Text
Public Class MatchSelection
    Dim team_list As String
    Dim line As String


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Main.Show()
        Me.Close()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If (Team1.Text = "" Or Team2.Text = "") Then
            MsgBox("Teams cannot be left blank")
        ElseIf (Team1.Text = Team2.Text) Then
            MsgBox("Teams cannot be same")
        ElseIf (Venue.Text = "") Then
            MsgBox("Venue cannot be left blank")
        Else
            Me.Hide()
            Toss.Show()
        End If
    End Sub

    Private Sub MatchSelection_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        team_list = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\teams\teamlist.txt"

        If Not File.Exists(team_list) Then
            MsgBox("No teams created!")
        Else
            Using reader1 As StreamReader = New StreamReader(team_list)

                line = reader1.ReadLine()
                While (line <> Nothing)
                    Team1.Items.Add(line)
                    Team2.Items.Add(line)
                    line = reader1.ReadLine()
                End While
            End Using
        End If

    End Sub
End Class