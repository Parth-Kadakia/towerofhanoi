﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CreateTeam
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Name1 = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.BwP1 = New System.Windows.Forms.NumericUpDown()
        Me.BwP2 = New System.Windows.Forms.NumericUpDown()
        Me.BwP3 = New System.Windows.Forms.NumericUpDown()
        Me.BatP5 = New System.Windows.Forms.NumericUpDown()
        Me.BatP4 = New System.Windows.Forms.NumericUpDown()
        Me.BatP3 = New System.Windows.Forms.NumericUpDown()
        Me.BatP2 = New System.Windows.Forms.NumericUpDown()
        Me.BatP1 = New System.Windows.Forms.NumericUpDown()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.tname = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Name5 = New System.Windows.Forms.TextBox()
        Me.Name4 = New System.Windows.Forms.TextBox()
        Me.Name3 = New System.Windows.Forms.TextBox()
        Me.Name2 = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        CType(Me.BwP1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BwP2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BwP3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BatP5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BatP4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BatP3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BatP2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BatP1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Name1
        '
        Me.Name1.Location = New System.Drawing.Point(246, 171)
        Me.Name1.Multiline = True
        Me.Name1.Name = "Name1"
        Me.Name1.Size = New System.Drawing.Size(377, 29)
        Me.Name1.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.BwP1)
        Me.GroupBox1.Controls.Add(Me.BwP2)
        Me.GroupBox1.Controls.Add(Me.BwP3)
        Me.GroupBox1.Controls.Add(Me.BatP5)
        Me.GroupBox1.Controls.Add(Me.BatP4)
        Me.GroupBox1.Controls.Add(Me.BatP3)
        Me.GroupBox1.Controls.Add(Me.BatP2)
        Me.GroupBox1.Controls.Add(Me.BatP1)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.tname)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Name5)
        Me.GroupBox1.Controls.Add(Me.Name4)
        Me.GroupBox1.Controls.Add(Me.Name3)
        Me.GroupBox1.Controls.Add(Me.Name2)
        Me.GroupBox1.Controls.Add(Me.Name1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1050, 572)
        Me.GroupBox1.TabIndex = 5
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Team Creation"
        '
        'BwP1
        '
        Me.BwP1.Location = New System.Drawing.Point(761, 378)
        Me.BwP1.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.BwP1.Name = "BwP1"
        Me.BwP1.Size = New System.Drawing.Size(70, 29)
        Me.BwP1.TabIndex = 60
        '
        'BwP2
        '
        Me.BwP2.Location = New System.Drawing.Point(761, 332)
        Me.BwP2.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.BwP2.Name = "BwP2"
        Me.BwP2.Size = New System.Drawing.Size(70, 29)
        Me.BwP2.TabIndex = 59
        '
        'BwP3
        '
        Me.BwP3.Location = New System.Drawing.Point(761, 278)
        Me.BwP3.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.BwP3.Name = "BwP3"
        Me.BwP3.Size = New System.Drawing.Size(70, 29)
        Me.BwP3.TabIndex = 58
        '
        'BatP5
        '
        Me.BatP5.Location = New System.Drawing.Point(650, 378)
        Me.BatP5.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.BatP5.Name = "BatP5"
        Me.BatP5.Size = New System.Drawing.Size(70, 29)
        Me.BatP5.TabIndex = 57
        '
        'BatP4
        '
        Me.BatP4.Location = New System.Drawing.Point(650, 332)
        Me.BatP4.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.BatP4.Name = "BatP4"
        Me.BatP4.Size = New System.Drawing.Size(70, 29)
        Me.BatP4.TabIndex = 56
        '
        'BatP3
        '
        Me.BatP3.Location = New System.Drawing.Point(650, 278)
        Me.BatP3.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.BatP3.Name = "BatP3"
        Me.BatP3.Size = New System.Drawing.Size(70, 29)
        Me.BatP3.TabIndex = 55
        '
        'BatP2
        '
        Me.BatP2.Location = New System.Drawing.Point(650, 224)
        Me.BatP2.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.BatP2.Name = "BatP2"
        Me.BatP2.Size = New System.Drawing.Size(70, 29)
        Me.BatP2.TabIndex = 54
        '
        'BatP1
        '
        Me.BatP1.Location = New System.Drawing.Point(650, 171)
        Me.BatP1.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.BatP1.Name = "BatP1"
        Me.BatP1.Size = New System.Drawing.Size(70, 29)
        Me.BatP1.TabIndex = 53
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Franklin Gothic Heavy", 8.142858!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(740, 124)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(124, 25)
        Me.Label10.TabIndex = 52
        Me.Label10.Text = "Bowl Points"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Franklin Gothic Heavy", 8.142858!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(624, 124)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(110, 25)
        Me.Label9.TabIndex = 51
        Me.Label9.Text = "Bat Points"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Franklin Gothic Heavy", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(398, 124)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(90, 36)
        Me.Label8.TabIndex = 50
        Me.Label8.Text = "Name"
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Franklin Gothic Heavy", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(42, 442)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(277, 86)
        Me.Button1.TabIndex = 49
        Me.Button1.Text = "Save Team"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Franklin Gothic Heavy", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(665, 442)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(316, 86)
        Me.Button2.TabIndex = 48
        Me.Button2.Text = "Main Menu"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'tname
        '
        Me.tname.Location = New System.Drawing.Point(246, 72)
        Me.tname.Multiline = True
        Me.tname.Name = "tname"
        Me.tname.Size = New System.Drawing.Size(377, 29)
        Me.tname.TabIndex = 27
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(42, 75)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(120, 25)
        Me.Label7.TabIndex = 26
        Me.Label7.Text = "Team Name"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(37, 382)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(178, 25)
        Me.Label5.TabIndex = 23
        Me.Label5.Text = "All Rounder/Bowler"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(37, 332)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(178, 25)
        Me.Label4.TabIndex = 22
        Me.Label4.Text = "All Rounder/Bowler"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(37, 282)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(178, 25)
        Me.Label3.TabIndex = 21
        Me.Label3.Text = "All Rounder/Bowler"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(37, 227)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(141, 25)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "Wicket Keeper"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(37, 175)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(94, 25)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Batsman "
        '
        'Name5
        '
        Me.Name5.Location = New System.Drawing.Point(246, 378)
        Me.Name5.Multiline = True
        Me.Name5.Name = "Name5"
        Me.Name5.Size = New System.Drawing.Size(377, 29)
        Me.Name5.TabIndex = 8
        '
        'Name4
        '
        Me.Name4.Location = New System.Drawing.Point(246, 332)
        Me.Name4.Multiline = True
        Me.Name4.Name = "Name4"
        Me.Name4.Size = New System.Drawing.Size(377, 29)
        Me.Name4.TabIndex = 7
        '
        'Name3
        '
        Me.Name3.Location = New System.Drawing.Point(246, 278)
        Me.Name3.Multiline = True
        Me.Name3.Name = "Name3"
        Me.Name3.Size = New System.Drawing.Size(377, 29)
        Me.Name3.TabIndex = 6
        '
        'Name2
        '
        Me.Name2.Location = New System.Drawing.Point(246, 224)
        Me.Name2.Multiline = True
        Me.Name2.Name = "Name2"
        Me.Name2.Size = New System.Drawing.Size(377, 29)
        Me.Name2.TabIndex = 5
        '
        'CreateTeam
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 24.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1074, 606)
        Me.Controls.Add(Me.GroupBox1)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(1098, 670)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(1098, 670)
        Me.Name = "CreateTeam"
        Me.Text = "CreateTeam"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.BwP1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BwP2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BwP3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BatP5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BatP4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BatP3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BatP2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BatP1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Name1 As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents tname As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Name5 As TextBox
    Friend WithEvents Name4 As TextBox
    Friend WithEvents Name3 As TextBox
    Friend WithEvents Name2 As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents BatP1 As NumericUpDown
    Friend WithEvents BwP1 As NumericUpDown
    Friend WithEvents BwP2 As NumericUpDown
    Friend WithEvents BwP3 As NumericUpDown
    Friend WithEvents BatP5 As NumericUpDown
    Friend WithEvents BatP4 As NumericUpDown
    Friend WithEvents BatP3 As NumericUpDown
    Friend WithEvents BatP2 As NumericUpDown
End Class
