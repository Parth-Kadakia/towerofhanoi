﻿Imports System
Imports System.IO
Imports System.Text

Public Class CreateTeam
    Dim total_points As Integer
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Main.Show()
        Me.Close()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Using writer As StreamWriter = New StreamWriter(System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\teams\" & tname.Text & ".txt")
            writer.WriteLine(Name1.Text)
            writer.WriteLine(Name2.Text)
            writer.WriteLine(Name3.Text)
            writer.WriteLine(Name4.Text)
            writer.WriteLine(Name5.Text)
            writer.WriteLine(BatP1.Value)
            writer.WriteLine(BatP2.Value)
            writer.WriteLine(BatP3.Value)
            writer.WriteLine(BatP4.Value)
            writer.WriteLine(BatP5.Value)
            writer.WriteLine(BwP1.Value)
            writer.WriteLine(BwP2.Value)
            writer.WriteLine(BwP3.Value)
            MsgBox("Team Created Successfully")
            Name1.Clear()
            Name2.Clear()
            Name3.Clear()
            Name4.Clear()
            Name5.Clear()
            BatP1.ResetText()
            BatP2.ResetText()
            BatP3.ResetText()
            BatP4.ResetText()
            BatP5.ResetText()
            BwP1.ResetText()
            BwP2.ResetText()
            BwP3.ResetText()
        End Using

        Using sw As StreamWriter = File.AppendText(System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\teams\teamlist.txt")
            sw.WriteLine(tname.Text)
            tname.Clear()
        End Using
    End Sub

    Private Sub CreateTeam_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim direct As String
        direct = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\teams"
        If Not Directory.Exists(direct) Then
            Directory.CreateDirectory(direct)
        End If
    End Sub
End Class