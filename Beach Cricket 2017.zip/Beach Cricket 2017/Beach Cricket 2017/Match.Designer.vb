﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Match
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MatchText = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.T1TB = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.T1TW = New System.Windows.Forms.TextBox()
        Me.T1TS = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.T2BWLWK3 = New System.Windows.Forms.TextBox()
        Me.T2BWLWK2 = New System.Windows.Forms.TextBox()
        Me.T2BWLWK1 = New System.Windows.Forms.TextBox()
        Me.T2BWLRU3 = New System.Windows.Forms.TextBox()
        Me.T2BWLRU2 = New System.Windows.Forms.TextBox()
        Me.T2BWLRU1 = New System.Windows.Forms.TextBox()
        Me.T2BWLBO3 = New System.Windows.Forms.TextBox()
        Me.T2BWLBO2 = New System.Windows.Forms.TextBox()
        Me.T2BWLBO1 = New System.Windows.Forms.TextBox()
        Me.T2BW3 = New System.Windows.Forms.TextBox()
        Me.T2BW2 = New System.Windows.Forms.TextBox()
        Me.T2BW1 = New System.Windows.Forms.TextBox()
        Me.T1B5BF = New System.Windows.Forms.TextBox()
        Me.T1B4BF = New System.Windows.Forms.TextBox()
        Me.T1B3BF = New System.Windows.Forms.TextBox()
        Me.T1B2BF = New System.Windows.Forms.TextBox()
        Me.T1B1BF = New System.Windows.Forms.TextBox()
        Me.T1B5R = New System.Windows.Forms.TextBox()
        Me.T1B4R = New System.Windows.Forms.TextBox()
        Me.T1B3R = New System.Windows.Forms.TextBox()
        Me.T1B2R = New System.Windows.Forms.TextBox()
        Me.T1B1R = New System.Windows.Forms.TextBox()
        Me.T1D5 = New System.Windows.Forms.TextBox()
        Me.T1D4 = New System.Windows.Forms.TextBox()
        Me.T1D3 = New System.Windows.Forms.TextBox()
        Me.T1D2 = New System.Windows.Forms.TextBox()
        Me.T1D1 = New System.Windows.Forms.TextBox()
        Me.T1B5 = New System.Windows.Forms.TextBox()
        Me.T1B4 = New System.Windows.Forms.TextBox()
        Me.T1B3 = New System.Windows.Forms.TextBox()
        Me.T1B2 = New System.Windows.Forms.TextBox()
        Me.T1B1 = New System.Windows.Forms.TextBox()
        Me.VenueText = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.T2TB = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.T2TW = New System.Windows.Forms.TextBox()
        Me.T2TS = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.T1BWLWK3 = New System.Windows.Forms.TextBox()
        Me.T1BWLWK2 = New System.Windows.Forms.TextBox()
        Me.T1BWLWK1 = New System.Windows.Forms.TextBox()
        Me.T1BWLRU3 = New System.Windows.Forms.TextBox()
        Me.T1BWLRU2 = New System.Windows.Forms.TextBox()
        Me.T1BWLRU1 = New System.Windows.Forms.TextBox()
        Me.T1BWLBO3 = New System.Windows.Forms.TextBox()
        Me.T1BWLBO2 = New System.Windows.Forms.TextBox()
        Me.T1BWLBO1 = New System.Windows.Forms.TextBox()
        Me.T1BW3 = New System.Windows.Forms.TextBox()
        Me.T1BW2 = New System.Windows.Forms.TextBox()
        Me.T1BW1 = New System.Windows.Forms.TextBox()
        Me.T2B5BF = New System.Windows.Forms.TextBox()
        Me.T2B4BF = New System.Windows.Forms.TextBox()
        Me.T2B3BF = New System.Windows.Forms.TextBox()
        Me.T2B2BF = New System.Windows.Forms.TextBox()
        Me.T2B1BF = New System.Windows.Forms.TextBox()
        Me.T2B5R = New System.Windows.Forms.TextBox()
        Me.T2B4R = New System.Windows.Forms.TextBox()
        Me.T2B3R = New System.Windows.Forms.TextBox()
        Me.T2B2R = New System.Windows.Forms.TextBox()
        Me.T2B1R = New System.Windows.Forms.TextBox()
        Me.T2D5 = New System.Windows.Forms.TextBox()
        Me.T2D4 = New System.Windows.Forms.TextBox()
        Me.T2D3 = New System.Windows.Forms.TextBox()
        Me.T2D2 = New System.Windows.Forms.TextBox()
        Me.T2D1 = New System.Windows.Forms.TextBox()
        Me.T2B5 = New System.Windows.Forms.TextBox()
        Me.T2B4 = New System.Windows.Forms.TextBox()
        Me.T2B3 = New System.Windows.Forms.TextBox()
        Me.T2B2 = New System.Windows.Forms.TextBox()
        Me.T2B1 = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.ResultText = New System.Windows.Forms.Label()
        Me.MatchResult = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'MatchText
        '
        Me.MatchText.AutoSize = True
        Me.MatchText.Font = New System.Drawing.Font("Franklin Gothic Heavy", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MatchText.Location = New System.Drawing.Point(13, 13)
        Me.MatchText.Name = "MatchText"
        Me.MatchText.Size = New System.Drawing.Size(345, 36)
        Me.MatchText.TabIndex = 0
        Me.MatchText.Text = "Match - India vs Australia"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.T1TB)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.T1TW)
        Me.GroupBox1.Controls.Add(Me.T1TS)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.T2BWLWK3)
        Me.GroupBox1.Controls.Add(Me.T2BWLWK2)
        Me.GroupBox1.Controls.Add(Me.T2BWLWK1)
        Me.GroupBox1.Controls.Add(Me.T2BWLRU3)
        Me.GroupBox1.Controls.Add(Me.T2BWLRU2)
        Me.GroupBox1.Controls.Add(Me.T2BWLRU1)
        Me.GroupBox1.Controls.Add(Me.T2BWLBO3)
        Me.GroupBox1.Controls.Add(Me.T2BWLBO2)
        Me.GroupBox1.Controls.Add(Me.T2BWLBO1)
        Me.GroupBox1.Controls.Add(Me.T2BW3)
        Me.GroupBox1.Controls.Add(Me.T2BW2)
        Me.GroupBox1.Controls.Add(Me.T2BW1)
        Me.GroupBox1.Controls.Add(Me.T1B5BF)
        Me.GroupBox1.Controls.Add(Me.T1B4BF)
        Me.GroupBox1.Controls.Add(Me.T1B3BF)
        Me.GroupBox1.Controls.Add(Me.T1B2BF)
        Me.GroupBox1.Controls.Add(Me.T1B1BF)
        Me.GroupBox1.Controls.Add(Me.T1B5R)
        Me.GroupBox1.Controls.Add(Me.T1B4R)
        Me.GroupBox1.Controls.Add(Me.T1B3R)
        Me.GroupBox1.Controls.Add(Me.T1B2R)
        Me.GroupBox1.Controls.Add(Me.T1B1R)
        Me.GroupBox1.Controls.Add(Me.T1D5)
        Me.GroupBox1.Controls.Add(Me.T1D4)
        Me.GroupBox1.Controls.Add(Me.T1D3)
        Me.GroupBox1.Controls.Add(Me.T1D2)
        Me.GroupBox1.Controls.Add(Me.T1D1)
        Me.GroupBox1.Controls.Add(Me.T1B5)
        Me.GroupBox1.Controls.Add(Me.T1B4)
        Me.GroupBox1.Controls.Add(Me.T1B3)
        Me.GroupBox1.Controls.Add(Me.T1B2)
        Me.GroupBox1.Controls.Add(Me.T1B1)
        Me.GroupBox1.Location = New System.Drawing.Point(21, 75)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(622, 687)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Team 1"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(534, 392)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(82, 25)
        Me.Label9.TabIndex = 44
        Me.Label9.Text = "Wickets"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(345, 392)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(54, 25)
        Me.Label8.TabIndex = 43
        Me.Label8.Text = "Balls"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(401, 392)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(41, 25)
        Me.Label6.TabIndex = 42
        Me.Label6.Text = "For"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(223, 392)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(28, 25)
        Me.Label5.TabIndex = 41
        Me.Label5.Text = "In"
        '
        'T1TB
        '
        Me.T1TB.Location = New System.Drawing.Point(257, 378)
        Me.T1TB.Multiline = True
        Me.T1TB.Name = "T1TB"
        Me.T1TB.ReadOnly = True
        Me.T1TB.Size = New System.Drawing.Size(82, 44)
        Me.T1TB.TabIndex = 40
        Me.T1TB.Text = "0"
        Me.T1TB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(11, 392)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(113, 25)
        Me.Label7.TabIndex = 39
        Me.Label7.Text = "Total Score"
        '
        'T1TW
        '
        Me.T1TW.Location = New System.Drawing.Point(446, 378)
        Me.T1TW.Multiline = True
        Me.T1TW.Name = "T1TW"
        Me.T1TW.ReadOnly = True
        Me.T1TW.Size = New System.Drawing.Size(82, 44)
        Me.T1TW.TabIndex = 38
        Me.T1TW.Text = "0"
        Me.T1TW.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T1TS
        '
        Me.T1TS.Location = New System.Drawing.Point(130, 378)
        Me.T1TS.Multiline = True
        Me.T1TS.Name = "T1TS"
        Me.T1TS.ReadOnly = True
        Me.T1TS.Size = New System.Drawing.Size(82, 44)
        Me.T1TS.TabIndex = 37
        Me.T1TS.Text = "0"
        Me.T1TS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(524, 450)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(57, 25)
        Me.Label4.TabIndex = 34
        Me.Label4.Text = "Wkts"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(416, 450)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(57, 25)
        Me.Label3.TabIndex = 33
        Me.Label3.Text = "Runs"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(302, 450)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(54, 25)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "Balls"
        '
        'T2BWLWK3
        '
        Me.T2BWLWK3.Location = New System.Drawing.Point(513, 622)
        Me.T2BWLWK3.Multiline = True
        Me.T2BWLWK3.Name = "T2BWLWK3"
        Me.T2BWLWK3.ReadOnly = True
        Me.T2BWLWK3.Size = New System.Drawing.Size(82, 44)
        Me.T2BWLWK3.TabIndex = 31
        Me.T2BWLWK3.Text = "0"
        Me.T2BWLWK3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T2BWLWK2
        '
        Me.T2BWLWK2.Location = New System.Drawing.Point(513, 556)
        Me.T2BWLWK2.Multiline = True
        Me.T2BWLWK2.Name = "T2BWLWK2"
        Me.T2BWLWK2.ReadOnly = True
        Me.T2BWLWK2.Size = New System.Drawing.Size(82, 44)
        Me.T2BWLWK2.TabIndex = 30
        Me.T2BWLWK2.Text = "0"
        Me.T2BWLWK2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T2BWLWK1
        '
        Me.T2BWLWK1.Location = New System.Drawing.Point(513, 489)
        Me.T2BWLWK1.Multiline = True
        Me.T2BWLWK1.Name = "T2BWLWK1"
        Me.T2BWLWK1.ReadOnly = True
        Me.T2BWLWK1.Size = New System.Drawing.Size(82, 44)
        Me.T2BWLWK1.TabIndex = 29
        Me.T2BWLWK1.Text = "0"
        Me.T2BWLWK1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T2BWLRU3
        '
        Me.T2BWLRU3.Location = New System.Drawing.Point(403, 622)
        Me.T2BWLRU3.Multiline = True
        Me.T2BWLRU3.Name = "T2BWLRU3"
        Me.T2BWLRU3.ReadOnly = True
        Me.T2BWLRU3.Size = New System.Drawing.Size(82, 44)
        Me.T2BWLRU3.TabIndex = 28
        Me.T2BWLRU3.Text = "0"
        Me.T2BWLRU3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T2BWLRU2
        '
        Me.T2BWLRU2.Location = New System.Drawing.Point(403, 556)
        Me.T2BWLRU2.Multiline = True
        Me.T2BWLRU2.Name = "T2BWLRU2"
        Me.T2BWLRU2.ReadOnly = True
        Me.T2BWLRU2.Size = New System.Drawing.Size(82, 44)
        Me.T2BWLRU2.TabIndex = 27
        Me.T2BWLRU2.Text = "0"
        Me.T2BWLRU2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T2BWLRU1
        '
        Me.T2BWLRU1.Location = New System.Drawing.Point(403, 489)
        Me.T2BWLRU1.Multiline = True
        Me.T2BWLRU1.Name = "T2BWLRU1"
        Me.T2BWLRU1.ReadOnly = True
        Me.T2BWLRU1.Size = New System.Drawing.Size(82, 44)
        Me.T2BWLRU1.TabIndex = 26
        Me.T2BWLRU1.Text = "0"
        Me.T2BWLRU1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T2BWLBO3
        '
        Me.T2BWLBO3.Location = New System.Drawing.Point(289, 622)
        Me.T2BWLBO3.Multiline = True
        Me.T2BWLBO3.Name = "T2BWLBO3"
        Me.T2BWLBO3.ReadOnly = True
        Me.T2BWLBO3.Size = New System.Drawing.Size(82, 44)
        Me.T2BWLBO3.TabIndex = 25
        Me.T2BWLBO3.Text = "0"
        Me.T2BWLBO3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T2BWLBO2
        '
        Me.T2BWLBO2.Location = New System.Drawing.Point(289, 556)
        Me.T2BWLBO2.Multiline = True
        Me.T2BWLBO2.Name = "T2BWLBO2"
        Me.T2BWLBO2.ReadOnly = True
        Me.T2BWLBO2.Size = New System.Drawing.Size(82, 44)
        Me.T2BWLBO2.TabIndex = 24
        Me.T2BWLBO2.Text = "0"
        Me.T2BWLBO2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T2BWLBO1
        '
        Me.T2BWLBO1.Location = New System.Drawing.Point(289, 489)
        Me.T2BWLBO1.Multiline = True
        Me.T2BWLBO1.Name = "T2BWLBO1"
        Me.T2BWLBO1.ReadOnly = True
        Me.T2BWLBO1.Size = New System.Drawing.Size(82, 44)
        Me.T2BWLBO1.TabIndex = 23
        Me.T2BWLBO1.Text = "0"
        Me.T2BWLBO1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T2BW3
        '
        Me.T2BW3.Location = New System.Drawing.Point(16, 622)
        Me.T2BW3.Multiline = True
        Me.T2BW3.Name = "T2BW3"
        Me.T2BW3.ReadOnly = True
        Me.T2BW3.Size = New System.Drawing.Size(192, 44)
        Me.T2BW3.TabIndex = 22
        '
        'T2BW2
        '
        Me.T2BW2.Location = New System.Drawing.Point(16, 556)
        Me.T2BW2.Multiline = True
        Me.T2BW2.Name = "T2BW2"
        Me.T2BW2.ReadOnly = True
        Me.T2BW2.Size = New System.Drawing.Size(192, 44)
        Me.T2BW2.TabIndex = 21
        '
        'T2BW1
        '
        Me.T2BW1.Location = New System.Drawing.Point(16, 489)
        Me.T2BW1.Multiline = True
        Me.T2BW1.Name = "T2BW1"
        Me.T2BW1.ReadOnly = True
        Me.T2BW1.Size = New System.Drawing.Size(192, 44)
        Me.T2BW1.TabIndex = 20
        '
        'T1B5BF
        '
        Me.T1B5BF.Location = New System.Drawing.Point(513, 317)
        Me.T1B5BF.Multiline = True
        Me.T1B5BF.Name = "T1B5BF"
        Me.T1B5BF.ReadOnly = True
        Me.T1B5BF.Size = New System.Drawing.Size(82, 44)
        Me.T1B5BF.TabIndex = 19
        Me.T1B5BF.Text = "0"
        Me.T1B5BF.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T1B4BF
        '
        Me.T1B4BF.Location = New System.Drawing.Point(513, 251)
        Me.T1B4BF.Multiline = True
        Me.T1B4BF.Name = "T1B4BF"
        Me.T1B4BF.ReadOnly = True
        Me.T1B4BF.Size = New System.Drawing.Size(82, 44)
        Me.T1B4BF.TabIndex = 18
        Me.T1B4BF.Text = "0"
        Me.T1B4BF.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T1B3BF
        '
        Me.T1B3BF.Location = New System.Drawing.Point(513, 184)
        Me.T1B3BF.Multiline = True
        Me.T1B3BF.Name = "T1B3BF"
        Me.T1B3BF.ReadOnly = True
        Me.T1B3BF.Size = New System.Drawing.Size(82, 44)
        Me.T1B3BF.TabIndex = 17
        Me.T1B3BF.Text = "0"
        Me.T1B3BF.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T1B2BF
        '
        Me.T1B2BF.Location = New System.Drawing.Point(513, 118)
        Me.T1B2BF.Multiline = True
        Me.T1B2BF.Name = "T1B2BF"
        Me.T1B2BF.ReadOnly = True
        Me.T1B2BF.Size = New System.Drawing.Size(82, 44)
        Me.T1B2BF.TabIndex = 16
        Me.T1B2BF.Text = "0"
        Me.T1B2BF.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T1B1BF
        '
        Me.T1B1BF.Location = New System.Drawing.Point(513, 51)
        Me.T1B1BF.Multiline = True
        Me.T1B1BF.Name = "T1B1BF"
        Me.T1B1BF.ReadOnly = True
        Me.T1B1BF.Size = New System.Drawing.Size(82, 44)
        Me.T1B1BF.TabIndex = 15
        Me.T1B1BF.Text = "0"
        Me.T1B1BF.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T1B5R
        '
        Me.T1B5R.Location = New System.Drawing.Point(425, 317)
        Me.T1B5R.Multiline = True
        Me.T1B5R.Name = "T1B5R"
        Me.T1B5R.ReadOnly = True
        Me.T1B5R.Size = New System.Drawing.Size(82, 44)
        Me.T1B5R.TabIndex = 14
        Me.T1B5R.Text = "0"
        Me.T1B5R.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T1B4R
        '
        Me.T1B4R.Location = New System.Drawing.Point(425, 251)
        Me.T1B4R.Multiline = True
        Me.T1B4R.Name = "T1B4R"
        Me.T1B4R.ReadOnly = True
        Me.T1B4R.Size = New System.Drawing.Size(82, 44)
        Me.T1B4R.TabIndex = 13
        Me.T1B4R.Text = "0"
        Me.T1B4R.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T1B3R
        '
        Me.T1B3R.Location = New System.Drawing.Point(425, 184)
        Me.T1B3R.Multiline = True
        Me.T1B3R.Name = "T1B3R"
        Me.T1B3R.ReadOnly = True
        Me.T1B3R.Size = New System.Drawing.Size(82, 44)
        Me.T1B3R.TabIndex = 12
        Me.T1B3R.Text = "0"
        Me.T1B3R.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T1B2R
        '
        Me.T1B2R.Location = New System.Drawing.Point(425, 118)
        Me.T1B2R.Multiline = True
        Me.T1B2R.Name = "T1B2R"
        Me.T1B2R.ReadOnly = True
        Me.T1B2R.Size = New System.Drawing.Size(82, 44)
        Me.T1B2R.TabIndex = 11
        Me.T1B2R.Text = "0"
        Me.T1B2R.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T1B1R
        '
        Me.T1B1R.Location = New System.Drawing.Point(425, 51)
        Me.T1B1R.Multiline = True
        Me.T1B1R.Name = "T1B1R"
        Me.T1B1R.ReadOnly = True
        Me.T1B1R.Size = New System.Drawing.Size(82, 44)
        Me.T1B1R.TabIndex = 10
        Me.T1B1R.Text = "0"
        Me.T1B1R.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T1D5
        '
        Me.T1D5.Location = New System.Drawing.Point(227, 317)
        Me.T1D5.Multiline = True
        Me.T1D5.Name = "T1D5"
        Me.T1D5.ReadOnly = True
        Me.T1D5.Size = New System.Drawing.Size(192, 44)
        Me.T1D5.TabIndex = 9
        '
        'T1D4
        '
        Me.T1D4.Location = New System.Drawing.Point(227, 251)
        Me.T1D4.Multiline = True
        Me.T1D4.Name = "T1D4"
        Me.T1D4.ReadOnly = True
        Me.T1D4.Size = New System.Drawing.Size(192, 44)
        Me.T1D4.TabIndex = 8
        '
        'T1D3
        '
        Me.T1D3.Location = New System.Drawing.Point(227, 184)
        Me.T1D3.Multiline = True
        Me.T1D3.Name = "T1D3"
        Me.T1D3.ReadOnly = True
        Me.T1D3.Size = New System.Drawing.Size(192, 44)
        Me.T1D3.TabIndex = 7
        '
        'T1D2
        '
        Me.T1D2.Location = New System.Drawing.Point(227, 118)
        Me.T1D2.Multiline = True
        Me.T1D2.Name = "T1D2"
        Me.T1D2.ReadOnly = True
        Me.T1D2.Size = New System.Drawing.Size(192, 44)
        Me.T1D2.TabIndex = 6
        '
        'T1D1
        '
        Me.T1D1.Location = New System.Drawing.Point(227, 51)
        Me.T1D1.Multiline = True
        Me.T1D1.Name = "T1D1"
        Me.T1D1.ReadOnly = True
        Me.T1D1.Size = New System.Drawing.Size(192, 44)
        Me.T1D1.TabIndex = 5
        '
        'T1B5
        '
        Me.T1B5.Location = New System.Drawing.Point(16, 317)
        Me.T1B5.Multiline = True
        Me.T1B5.Name = "T1B5"
        Me.T1B5.ReadOnly = True
        Me.T1B5.Size = New System.Drawing.Size(192, 44)
        Me.T1B5.TabIndex = 4
        '
        'T1B4
        '
        Me.T1B4.Location = New System.Drawing.Point(16, 251)
        Me.T1B4.Multiline = True
        Me.T1B4.Name = "T1B4"
        Me.T1B4.ReadOnly = True
        Me.T1B4.Size = New System.Drawing.Size(192, 44)
        Me.T1B4.TabIndex = 3
        '
        'T1B3
        '
        Me.T1B3.Location = New System.Drawing.Point(16, 184)
        Me.T1B3.Multiline = True
        Me.T1B3.Name = "T1B3"
        Me.T1B3.ReadOnly = True
        Me.T1B3.Size = New System.Drawing.Size(192, 44)
        Me.T1B3.TabIndex = 2
        '
        'T1B2
        '
        Me.T1B2.Location = New System.Drawing.Point(16, 118)
        Me.T1B2.Multiline = True
        Me.T1B2.Name = "T1B2"
        Me.T1B2.ReadOnly = True
        Me.T1B2.Size = New System.Drawing.Size(192, 44)
        Me.T1B2.TabIndex = 1
        '
        'T1B1
        '
        Me.T1B1.Location = New System.Drawing.Point(16, 51)
        Me.T1B1.Multiline = True
        Me.T1B1.Name = "T1B1"
        Me.T1B1.ReadOnly = True
        Me.T1B1.Size = New System.Drawing.Size(192, 44)
        Me.T1B1.TabIndex = 0
        '
        'VenueText
        '
        Me.VenueText.AutoSize = True
        Me.VenueText.Font = New System.Drawing.Font("Franklin Gothic Heavy", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VenueText.Location = New System.Drawing.Point(667, 13)
        Me.VenueText.Name = "VenueText"
        Me.VenueText.Size = New System.Drawing.Size(253, 36)
        Me.VenueText.TabIndex = 3
        Me.VenueText.Text = "Venue - Xyz Beach"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.T2TB)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.T2TW)
        Me.GroupBox2.Controls.Add(Me.T2TS)
        Me.GroupBox2.Controls.Add(Me.Label16)
        Me.GroupBox2.Controls.Add(Me.Label17)
        Me.GroupBox2.Controls.Add(Me.Label18)
        Me.GroupBox2.Controls.Add(Me.T1BWLWK3)
        Me.GroupBox2.Controls.Add(Me.T1BWLWK2)
        Me.GroupBox2.Controls.Add(Me.T1BWLWK1)
        Me.GroupBox2.Controls.Add(Me.T1BWLRU3)
        Me.GroupBox2.Controls.Add(Me.T1BWLRU2)
        Me.GroupBox2.Controls.Add(Me.T1BWLRU1)
        Me.GroupBox2.Controls.Add(Me.T1BWLBO3)
        Me.GroupBox2.Controls.Add(Me.T1BWLBO2)
        Me.GroupBox2.Controls.Add(Me.T1BWLBO1)
        Me.GroupBox2.Controls.Add(Me.T1BW3)
        Me.GroupBox2.Controls.Add(Me.T1BW2)
        Me.GroupBox2.Controls.Add(Me.T1BW1)
        Me.GroupBox2.Controls.Add(Me.T2B5BF)
        Me.GroupBox2.Controls.Add(Me.T2B4BF)
        Me.GroupBox2.Controls.Add(Me.T2B3BF)
        Me.GroupBox2.Controls.Add(Me.T2B2BF)
        Me.GroupBox2.Controls.Add(Me.T2B1BF)
        Me.GroupBox2.Controls.Add(Me.T2B5R)
        Me.GroupBox2.Controls.Add(Me.T2B4R)
        Me.GroupBox2.Controls.Add(Me.T2B3R)
        Me.GroupBox2.Controls.Add(Me.T2B2R)
        Me.GroupBox2.Controls.Add(Me.T2B1R)
        Me.GroupBox2.Controls.Add(Me.T2D5)
        Me.GroupBox2.Controls.Add(Me.T2D4)
        Me.GroupBox2.Controls.Add(Me.T2D3)
        Me.GroupBox2.Controls.Add(Me.T2D2)
        Me.GroupBox2.Controls.Add(Me.T2D1)
        Me.GroupBox2.Controls.Add(Me.T2B5)
        Me.GroupBox2.Controls.Add(Me.T2B4)
        Me.GroupBox2.Controls.Add(Me.T2B3)
        Me.GroupBox2.Controls.Add(Me.T2B2)
        Me.GroupBox2.Controls.Add(Me.T2B1)
        Me.GroupBox2.Location = New System.Drawing.Point(675, 75)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(622, 687)
        Me.GroupBox2.TabIndex = 45
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Team 2"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(534, 392)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(82, 25)
        Me.Label11.TabIndex = 44
        Me.Label11.Text = "Wickets"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(345, 392)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(54, 25)
        Me.Label12.TabIndex = 43
        Me.Label12.Text = "Balls"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(401, 392)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(41, 25)
        Me.Label13.TabIndex = 42
        Me.Label13.Text = "For"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(223, 392)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(28, 25)
        Me.Label14.TabIndex = 41
        Me.Label14.Text = "In"
        '
        'T2TB
        '
        Me.T2TB.Location = New System.Drawing.Point(257, 378)
        Me.T2TB.Multiline = True
        Me.T2TB.Name = "T2TB"
        Me.T2TB.ReadOnly = True
        Me.T2TB.Size = New System.Drawing.Size(82, 44)
        Me.T2TB.TabIndex = 40
        Me.T2TB.Text = "0"
        Me.T2TB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(11, 392)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(113, 25)
        Me.Label15.TabIndex = 39
        Me.Label15.Text = "Total Score"
        '
        'T2TW
        '
        Me.T2TW.Location = New System.Drawing.Point(446, 378)
        Me.T2TW.Multiline = True
        Me.T2TW.Name = "T2TW"
        Me.T2TW.ReadOnly = True
        Me.T2TW.Size = New System.Drawing.Size(82, 44)
        Me.T2TW.TabIndex = 38
        Me.T2TW.Text = "0"
        Me.T2TW.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T2TS
        '
        Me.T2TS.Location = New System.Drawing.Point(130, 378)
        Me.T2TS.Multiline = True
        Me.T2TS.Name = "T2TS"
        Me.T2TS.ReadOnly = True
        Me.T2TS.Size = New System.Drawing.Size(82, 44)
        Me.T2TS.TabIndex = 37
        Me.T2TS.Text = "0"
        Me.T2TS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(524, 450)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(57, 25)
        Me.Label16.TabIndex = 34
        Me.Label16.Text = "Wkts"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(416, 450)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(57, 25)
        Me.Label17.TabIndex = 33
        Me.Label17.Text = "Runs"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(302, 450)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(54, 25)
        Me.Label18.TabIndex = 32
        Me.Label18.Text = "Balls"
        '
        'T1BWLWK3
        '
        Me.T1BWLWK3.Location = New System.Drawing.Point(513, 622)
        Me.T1BWLWK3.Multiline = True
        Me.T1BWLWK3.Name = "T1BWLWK3"
        Me.T1BWLWK3.ReadOnly = True
        Me.T1BWLWK3.Size = New System.Drawing.Size(82, 44)
        Me.T1BWLWK3.TabIndex = 31
        Me.T1BWLWK3.Text = "0"
        Me.T1BWLWK3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T1BWLWK2
        '
        Me.T1BWLWK2.Location = New System.Drawing.Point(513, 556)
        Me.T1BWLWK2.Multiline = True
        Me.T1BWLWK2.Name = "T1BWLWK2"
        Me.T1BWLWK2.ReadOnly = True
        Me.T1BWLWK2.Size = New System.Drawing.Size(82, 44)
        Me.T1BWLWK2.TabIndex = 30
        Me.T1BWLWK2.Text = "0"
        Me.T1BWLWK2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T1BWLWK1
        '
        Me.T1BWLWK1.Location = New System.Drawing.Point(513, 489)
        Me.T1BWLWK1.Multiline = True
        Me.T1BWLWK1.Name = "T1BWLWK1"
        Me.T1BWLWK1.ReadOnly = True
        Me.T1BWLWK1.Size = New System.Drawing.Size(82, 44)
        Me.T1BWLWK1.TabIndex = 29
        Me.T1BWLWK1.Text = "0"
        Me.T1BWLWK1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T1BWLRU3
        '
        Me.T1BWLRU3.Location = New System.Drawing.Point(403, 622)
        Me.T1BWLRU3.Multiline = True
        Me.T1BWLRU3.Name = "T1BWLRU3"
        Me.T1BWLRU3.ReadOnly = True
        Me.T1BWLRU3.Size = New System.Drawing.Size(82, 44)
        Me.T1BWLRU3.TabIndex = 28
        Me.T1BWLRU3.Text = "0"
        Me.T1BWLRU3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T1BWLRU2
        '
        Me.T1BWLRU2.Location = New System.Drawing.Point(403, 556)
        Me.T1BWLRU2.Multiline = True
        Me.T1BWLRU2.Name = "T1BWLRU2"
        Me.T1BWLRU2.ReadOnly = True
        Me.T1BWLRU2.Size = New System.Drawing.Size(82, 44)
        Me.T1BWLRU2.TabIndex = 27
        Me.T1BWLRU2.Text = "0"
        Me.T1BWLRU2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T1BWLRU1
        '
        Me.T1BWLRU1.Location = New System.Drawing.Point(403, 489)
        Me.T1BWLRU1.Multiline = True
        Me.T1BWLRU1.Name = "T1BWLRU1"
        Me.T1BWLRU1.ReadOnly = True
        Me.T1BWLRU1.Size = New System.Drawing.Size(82, 44)
        Me.T1BWLRU1.TabIndex = 26
        Me.T1BWLRU1.Text = "0"
        Me.T1BWLRU1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T1BWLBO3
        '
        Me.T1BWLBO3.Location = New System.Drawing.Point(289, 622)
        Me.T1BWLBO3.Multiline = True
        Me.T1BWLBO3.Name = "T1BWLBO3"
        Me.T1BWLBO3.ReadOnly = True
        Me.T1BWLBO3.Size = New System.Drawing.Size(82, 44)
        Me.T1BWLBO3.TabIndex = 25
        Me.T1BWLBO3.Text = "0"
        Me.T1BWLBO3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T1BWLBO2
        '
        Me.T1BWLBO2.Location = New System.Drawing.Point(289, 556)
        Me.T1BWLBO2.Multiline = True
        Me.T1BWLBO2.Name = "T1BWLBO2"
        Me.T1BWLBO2.ReadOnly = True
        Me.T1BWLBO2.Size = New System.Drawing.Size(82, 44)
        Me.T1BWLBO2.TabIndex = 24
        Me.T1BWLBO2.Text = "0"
        Me.T1BWLBO2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T1BWLBO1
        '
        Me.T1BWLBO1.Location = New System.Drawing.Point(289, 489)
        Me.T1BWLBO1.Multiline = True
        Me.T1BWLBO1.Name = "T1BWLBO1"
        Me.T1BWLBO1.ReadOnly = True
        Me.T1BWLBO1.Size = New System.Drawing.Size(82, 44)
        Me.T1BWLBO1.TabIndex = 23
        Me.T1BWLBO1.Text = "0"
        Me.T1BWLBO1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T1BW3
        '
        Me.T1BW3.Location = New System.Drawing.Point(16, 622)
        Me.T1BW3.Multiline = True
        Me.T1BW3.Name = "T1BW3"
        Me.T1BW3.ReadOnly = True
        Me.T1BW3.Size = New System.Drawing.Size(192, 44)
        Me.T1BW3.TabIndex = 22
        '
        'T1BW2
        '
        Me.T1BW2.Location = New System.Drawing.Point(16, 556)
        Me.T1BW2.Multiline = True
        Me.T1BW2.Name = "T1BW2"
        Me.T1BW2.ReadOnly = True
        Me.T1BW2.Size = New System.Drawing.Size(192, 44)
        Me.T1BW2.TabIndex = 21
        '
        'T1BW1
        '
        Me.T1BW1.Location = New System.Drawing.Point(16, 489)
        Me.T1BW1.Multiline = True
        Me.T1BW1.Name = "T1BW1"
        Me.T1BW1.ReadOnly = True
        Me.T1BW1.Size = New System.Drawing.Size(192, 44)
        Me.T1BW1.TabIndex = 20
        '
        'T2B5BF
        '
        Me.T2B5BF.Location = New System.Drawing.Point(513, 317)
        Me.T2B5BF.Multiline = True
        Me.T2B5BF.Name = "T2B5BF"
        Me.T2B5BF.ReadOnly = True
        Me.T2B5BF.Size = New System.Drawing.Size(82, 44)
        Me.T2B5BF.TabIndex = 19
        Me.T2B5BF.Text = "0"
        Me.T2B5BF.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T2B4BF
        '
        Me.T2B4BF.Location = New System.Drawing.Point(513, 251)
        Me.T2B4BF.Multiline = True
        Me.T2B4BF.Name = "T2B4BF"
        Me.T2B4BF.ReadOnly = True
        Me.T2B4BF.Size = New System.Drawing.Size(82, 44)
        Me.T2B4BF.TabIndex = 18
        Me.T2B4BF.Text = "0"
        Me.T2B4BF.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T2B3BF
        '
        Me.T2B3BF.Location = New System.Drawing.Point(513, 184)
        Me.T2B3BF.Multiline = True
        Me.T2B3BF.Name = "T2B3BF"
        Me.T2B3BF.ReadOnly = True
        Me.T2B3BF.Size = New System.Drawing.Size(82, 44)
        Me.T2B3BF.TabIndex = 17
        Me.T2B3BF.Text = "0"
        Me.T2B3BF.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T2B2BF
        '
        Me.T2B2BF.Location = New System.Drawing.Point(513, 118)
        Me.T2B2BF.Multiline = True
        Me.T2B2BF.Name = "T2B2BF"
        Me.T2B2BF.ReadOnly = True
        Me.T2B2BF.Size = New System.Drawing.Size(82, 44)
        Me.T2B2BF.TabIndex = 16
        Me.T2B2BF.Text = "0"
        Me.T2B2BF.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T2B1BF
        '
        Me.T2B1BF.Location = New System.Drawing.Point(513, 51)
        Me.T2B1BF.Multiline = True
        Me.T2B1BF.Name = "T2B1BF"
        Me.T2B1BF.ReadOnly = True
        Me.T2B1BF.Size = New System.Drawing.Size(82, 44)
        Me.T2B1BF.TabIndex = 15
        Me.T2B1BF.Text = "0"
        Me.T2B1BF.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T2B5R
        '
        Me.T2B5R.Location = New System.Drawing.Point(425, 317)
        Me.T2B5R.Multiline = True
        Me.T2B5R.Name = "T2B5R"
        Me.T2B5R.ReadOnly = True
        Me.T2B5R.Size = New System.Drawing.Size(82, 44)
        Me.T2B5R.TabIndex = 14
        Me.T2B5R.Text = "0"
        Me.T2B5R.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T2B4R
        '
        Me.T2B4R.Location = New System.Drawing.Point(425, 251)
        Me.T2B4R.Multiline = True
        Me.T2B4R.Name = "T2B4R"
        Me.T2B4R.ReadOnly = True
        Me.T2B4R.Size = New System.Drawing.Size(82, 44)
        Me.T2B4R.TabIndex = 13
        Me.T2B4R.Text = "0"
        Me.T2B4R.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T2B3R
        '
        Me.T2B3R.Location = New System.Drawing.Point(425, 184)
        Me.T2B3R.Multiline = True
        Me.T2B3R.Name = "T2B3R"
        Me.T2B3R.ReadOnly = True
        Me.T2B3R.Size = New System.Drawing.Size(82, 44)
        Me.T2B3R.TabIndex = 12
        Me.T2B3R.Text = "0"
        Me.T2B3R.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T2B2R
        '
        Me.T2B2R.Location = New System.Drawing.Point(425, 118)
        Me.T2B2R.Multiline = True
        Me.T2B2R.Name = "T2B2R"
        Me.T2B2R.ReadOnly = True
        Me.T2B2R.Size = New System.Drawing.Size(82, 44)
        Me.T2B2R.TabIndex = 11
        Me.T2B2R.Text = "0"
        Me.T2B2R.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T2B1R
        '
        Me.T2B1R.Location = New System.Drawing.Point(425, 51)
        Me.T2B1R.Multiline = True
        Me.T2B1R.Name = "T2B1R"
        Me.T2B1R.ReadOnly = True
        Me.T2B1R.Size = New System.Drawing.Size(82, 44)
        Me.T2B1R.TabIndex = 10
        Me.T2B1R.Text = "0"
        Me.T2B1R.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'T2D5
        '
        Me.T2D5.Location = New System.Drawing.Point(227, 317)
        Me.T2D5.Multiline = True
        Me.T2D5.Name = "T2D5"
        Me.T2D5.ReadOnly = True
        Me.T2D5.Size = New System.Drawing.Size(192, 44)
        Me.T2D5.TabIndex = 9
        '
        'T2D4
        '
        Me.T2D4.Location = New System.Drawing.Point(227, 251)
        Me.T2D4.Multiline = True
        Me.T2D4.Name = "T2D4"
        Me.T2D4.ReadOnly = True
        Me.T2D4.Size = New System.Drawing.Size(192, 44)
        Me.T2D4.TabIndex = 8
        '
        'T2D3
        '
        Me.T2D3.Location = New System.Drawing.Point(227, 184)
        Me.T2D3.Multiline = True
        Me.T2D3.Name = "T2D3"
        Me.T2D3.ReadOnly = True
        Me.T2D3.Size = New System.Drawing.Size(192, 44)
        Me.T2D3.TabIndex = 7
        '
        'T2D2
        '
        Me.T2D2.Location = New System.Drawing.Point(227, 118)
        Me.T2D2.Multiline = True
        Me.T2D2.Name = "T2D2"
        Me.T2D2.ReadOnly = True
        Me.T2D2.Size = New System.Drawing.Size(192, 44)
        Me.T2D2.TabIndex = 6
        '
        'T2D1
        '
        Me.T2D1.Location = New System.Drawing.Point(227, 51)
        Me.T2D1.Multiline = True
        Me.T2D1.Name = "T2D1"
        Me.T2D1.ReadOnly = True
        Me.T2D1.Size = New System.Drawing.Size(192, 44)
        Me.T2D1.TabIndex = 5
        '
        'T2B5
        '
        Me.T2B5.Location = New System.Drawing.Point(16, 317)
        Me.T2B5.Multiline = True
        Me.T2B5.Name = "T2B5"
        Me.T2B5.ReadOnly = True
        Me.T2B5.Size = New System.Drawing.Size(192, 44)
        Me.T2B5.TabIndex = 4
        '
        'T2B4
        '
        Me.T2B4.Location = New System.Drawing.Point(16, 251)
        Me.T2B4.Multiline = True
        Me.T2B4.Name = "T2B4"
        Me.T2B4.ReadOnly = True
        Me.T2B4.Size = New System.Drawing.Size(192, 44)
        Me.T2B4.TabIndex = 3
        '
        'T2B3
        '
        Me.T2B3.Location = New System.Drawing.Point(16, 184)
        Me.T2B3.Multiline = True
        Me.T2B3.Name = "T2B3"
        Me.T2B3.ReadOnly = True
        Me.T2B3.Size = New System.Drawing.Size(192, 44)
        Me.T2B3.TabIndex = 2
        '
        'T2B2
        '
        Me.T2B2.Location = New System.Drawing.Point(16, 118)
        Me.T2B2.Multiline = True
        Me.T2B2.Name = "T2B2"
        Me.T2B2.ReadOnly = True
        Me.T2B2.Size = New System.Drawing.Size(192, 44)
        Me.T2B2.TabIndex = 1
        '
        'T2B1
        '
        Me.T2B1.Location = New System.Drawing.Point(16, 51)
        Me.T2B1.Multiline = True
        Me.T2B1.Name = "T2B1"
        Me.T2B1.ReadOnly = True
        Me.T2B1.Size = New System.Drawing.Size(192, 44)
        Me.T2B1.TabIndex = 0
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Franklin Gothic Heavy", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(493, 857)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(316, 65)
        Me.Button2.TabIndex = 46
        Me.Button2.Text = "Main Menu"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Franklin Gothic Heavy", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(941, 857)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(350, 65)
        Me.Button1.TabIndex = 47
        Me.Button1.Text = "Save Scorecard"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Franklin Gothic Heavy", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(21, 857)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(176, 65)
        Me.Button3.TabIndex = 48
        Me.Button3.Text = "Sim 1st Inn"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'ResultText
        '
        Me.ResultText.AutoSize = True
        Me.ResultText.Font = New System.Drawing.Font("Franklin Gothic Heavy", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ResultText.Location = New System.Drawing.Point(613, 784)
        Me.ResultText.Name = "ResultText"
        Me.ResultText.Size = New System.Drawing.Size(324, 36)
        Me.ResultText.TabIndex = 49
        Me.ResultText.Text = "India Win by 10 Wickets"
        Me.ResultText.Visible = False
        '
        'MatchResult
        '
        Me.MatchResult.AutoSize = True
        Me.MatchResult.Font = New System.Drawing.Font("Franklin Gothic Heavy", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MatchResult.Location = New System.Drawing.Point(304, 784)
        Me.MatchResult.Name = "MatchResult"
        Me.MatchResult.Size = New System.Drawing.Size(210, 36)
        Me.MatchResult.TabIndex = 50
        Me.MatchResult.Text = "Match Result - "
        Me.MatchResult.Visible = False
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Franklin Gothic Heavy", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(216, 857)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(176, 65)
        Me.Button4.TabIndex = 51
        Me.Button4.Text = "Sim 2nd Inn"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Match
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 24.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1307, 934)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.MatchResult)
        Me.Controls.Add(Me.ResultText)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.VenueText)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.MatchText)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(1331, 998)
        Me.MinimumSize = New System.Drawing.Size(1331, 998)
        Me.Name = "Match"
        Me.Text = "Match"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MatchText As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents T1B5 As TextBox
    Friend WithEvents T1B4 As TextBox
    Friend WithEvents T1B3 As TextBox
    Friend WithEvents T1B2 As TextBox
    Friend WithEvents T1B1 As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents T1TB As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents T1TW As TextBox
    Friend WithEvents T1TS As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents T2BWLWK3 As TextBox
    Friend WithEvents T2BWLWK2 As TextBox
    Friend WithEvents T2BWLWK1 As TextBox
    Friend WithEvents T2BWLRU3 As TextBox
    Friend WithEvents T2BWLRU2 As TextBox
    Friend WithEvents T2BWLRU1 As TextBox
    Friend WithEvents T2BWLBO3 As TextBox
    Friend WithEvents T2BWLBO2 As TextBox
    Friend WithEvents T2BWLBO1 As TextBox
    Friend WithEvents T2BW3 As TextBox
    Friend WithEvents T2BW2 As TextBox
    Friend WithEvents T2BW1 As TextBox
    Friend WithEvents T1B5BF As TextBox
    Friend WithEvents T1B4BF As TextBox
    Friend WithEvents T1B3BF As TextBox
    Friend WithEvents T1B2BF As TextBox
    Friend WithEvents T1B1BF As TextBox
    Friend WithEvents T1B5R As TextBox
    Friend WithEvents T1B4R As TextBox
    Friend WithEvents T1B3R As TextBox
    Friend WithEvents T1B2R As TextBox
    Friend WithEvents T1B1R As TextBox
    Friend WithEvents T1D5 As TextBox
    Friend WithEvents T1D4 As TextBox
    Friend WithEvents T1D3 As TextBox
    Friend WithEvents T1D2 As TextBox
    Friend WithEvents T1D1 As TextBox
    Friend WithEvents VenueText As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents T2TB As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents T2TW As TextBox
    Friend WithEvents T2TS As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents T1BWLWK3 As TextBox
    Friend WithEvents T1BWLWK2 As TextBox
    Friend WithEvents T1BWLWK1 As TextBox
    Friend WithEvents T1BWLRU3 As TextBox
    Friend WithEvents T1BWLRU2 As TextBox
    Friend WithEvents T1BWLRU1 As TextBox
    Friend WithEvents T1BWLBO3 As TextBox
    Friend WithEvents T1BWLBO2 As TextBox
    Friend WithEvents T1BWLBO1 As TextBox
    Friend WithEvents T1BW3 As TextBox
    Friend WithEvents T1BW2 As TextBox
    Friend WithEvents T1BW1 As TextBox
    Friend WithEvents T2B5BF As TextBox
    Friend WithEvents T2B4BF As TextBox
    Friend WithEvents T2B3BF As TextBox
    Friend WithEvents T2B2BF As TextBox
    Friend WithEvents T2B1BF As TextBox
    Friend WithEvents T2B5R As TextBox
    Friend WithEvents T2B4R As TextBox
    Friend WithEvents T2B3R As TextBox
    Friend WithEvents T2B2R As TextBox
    Friend WithEvents T2B1R As TextBox
    Friend WithEvents T2D5 As TextBox
    Friend WithEvents T2D4 As TextBox
    Friend WithEvents T2D3 As TextBox
    Friend WithEvents T2D2 As TextBox
    Friend WithEvents T2D1 As TextBox
    Friend WithEvents T2B5 As TextBox
    Friend WithEvents T2B4 As TextBox
    Friend WithEvents T2B3 As TextBox
    Friend WithEvents T2B2 As TextBox
    Friend WithEvents T2B1 As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents ResultText As Label
    Friend WithEvents MatchResult As Label
    Friend WithEvents Button4 As Button
End Class
